import {randomBytes,randomUUID,createHash,scrypt as cryptoScrypt,timingSafeEqual} from 'node:crypto';
import {promisify} from 'node:util';
import {validateAuthForm,validPhone} from '../src/app/core/auth-validation.ts';
import {DEFAULT_OWNER,ORDER_TYPES,ORDER_STATUSES,POLICY_VERSION} from '../src/app/core/portal-config.mjs';

const scrypt=promisify(cryptoScrypt),SESSION_AGE=8*3600_000,IDLE_AGE=30*60_000;
const digest=value=>createHash('sha256').update(value).digest('hex');
const canonical=value=>value.normalize('NFKC').trim().toLocaleLowerCase('tr-TR');
const publicUser=user=>({id:user.id,username:user.username,displayName:user.displayName,email:user.email,phone:user.phone,role:user.role,status:user.status,createdAt:user.createdAt});
const fail=(status,message,fields)=>{const error=new Error(message);Object.assign(error,{status,fields});throw error;};
function text(value,max=4000){return typeof value==='string'?value.trim().slice(0,max+1):'';}
export async function hashPassword(password){const salt=randomBytes(16).toString('hex');const key=await scrypt(password,salt,64,{N:32768,r:8,p:3,maxmem:64*1024*1024});return `scrypt$${salt}$${key.toString('hex')}`;}
async function matches(password,hash){if(typeof password!=='string'||password.length>128)return false;const[,salt,key]=hash.split('$');const actual=await scrypt(password,salt,64,{N:32768,r:8,p:3,maxmem:64*1024*1024});return timingSafeEqual(actual,Buffer.from(key,'hex'));}
function notify(state,kind,ref,title){state.notifications.unshift({id:randomUUID(),kind,ref,title,createdAt:new Date().toISOString(),read:false});}
function revoke(state,id){state.sessions=state.sessions.filter(session=>session.userId!==id);}
function limit(state,key,max,windowMs,now){state.limits=state.limits.filter(row=>row.until>now);let row=state.limits.find(row=>row.key===key);if(!row){row={key,count:0,until:now+windowMs};state.limits.push(row);}row.count++;if(row.count>max)fail(429,'Çok fazla deneme yapıldı. Lütfen daha sonra tekrar deneyin.');}
function sessionFor(state,token,now){const session=state.sessions.find(row=>row.hash===digest(token));if(!session)return null;const user=state.users.find(row=>row.id===session.userId);if(!user||user.status!=='active'||session.expires<now||session.lastSeen+IDLE_AGE<now){state.sessions=state.sessions.filter(row=>row!==session);return null;}if(session.lastSeen+60_000<now)session.lastSeen=now;return{session,user};}
function newSession(state,user,now){const token=randomBytes(32).toString('base64url');state.sessions.push({hash:digest(token),userId:user.id,createdAt:now,lastSeen:now,expires:now+SESSION_AGE});return token;}
function ownProfile(state){const user=state.users.find(row=>row.id===state.ownerId);return user?{displayName:user.displayName,email:user.email,phone:user.phone}:DEFAULT_OWNER;}

export function createPortal(repository,{adminPassword='',now=()=>Date.now()}={}){
 let dummyHash;
 return async function handle(request,{ip='local'}={}){
  const url=new URL(request.url),route=url.pathname.replace(/^\/\.netlify\/functions\/api/,'').replace(/^\/api/,'').replace(/\/$/,'')||'/',method=request.method;
  const headers={'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'};
  const secure=url.protocol==='https:',cookieName=secure?'__Host-portfolio_session':'portfolio_session';
  const cookie=(token='')=>`${cookieName}=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${token?SESSION_AGE/1000:0}${secure?'; Secure':''}`;
  const respond=(status,body,token)=>new Response(JSON.stringify(body),{status,headers:{...headers,...(token!==undefined?{'set-cookie':cookie(token)}:{})}});
  if(!['GET','POST','PATCH','DELETE'].includes(method))return respond(405,{error:'Bu istek yöntemi desteklenmiyor.'});
  let body={};
  if(method!=='GET'){
   if(request.headers.get('origin')!==url.origin||request.headers.get('x-portfolio-request')!=='1')return respond(403,{error:'İstek kaynağı doğrulanamadı.'});
   if(!request.headers.get('content-type')?.startsWith('application/json'))return respond(415,{error:'JSON içerik gerekli.'});
   try{const raw=await request.text();if(raw.length>24_000)return respond(413,{error:'İstek çok büyük.'});body=JSON.parse(raw||'{}');if(!body||typeof body!=='object'||Array.isArray(body))throw Error();}catch{return respond(400,{error:'İstek içeriği geçersiz.'});}
  }
  const token=(request.headers.get('cookie')||'').split(';').map(row=>row.trim()).find(row=>row.startsWith(cookieName+'='))?.slice(cookieName.length+1)||'';
  try{return await repository.transact(async state=>{
   const time=now(),iso=new Date(time).toISOString();let outputToken;
   try{
    state.sessions=state.sessions.filter(row=>row.expires>time&&row.lastSeen+IDLE_AGE>time);
    if(!state.ownerId&&adminPassword.length>=16){
     const user={id:randomUUID(),username:'berkan',displayName:DEFAULT_OWNER.displayName,email:DEFAULT_OWNER.email,phone:DEFAULT_OWNER.phone,role:'admin',status:'active',passwordHash:await hashPassword(adminPassword),createdAt:iso};state.users.push(user);state.ownerId=user.id;
    }
    if(route==='/public-profile'&&method==='GET')return respond(200,{profile:ownProfile(state),accountServiceReady:Boolean(state.ownerId),orderTypes:ORDER_TYPES});
    if(!state.ownerId)fail(503,'Üyelik hizmetinin yönetici başlangıç ayarı henüz yapılmadı.');
    const identity=token?sessionFor(state,token,time):null;
    const requireUser=()=>{if(!identity)fail(401,'Bu işlem için giriş yapmalısınız.');return identity.user;};
    const requireAdmin=()=>{const user=requireUser();if(user.role!=='admin')fail(403,'Bu alan yalnızca yöneticiye açıktır.');return user;};
    if(route==='/session'&&method==='GET')return respond(200,{user:identity?publicUser(identity.user):null});
    if(route==='/auth/register'&&method==='POST'){
     limit(state,'signup:'+digest(ip),10,3600_000,time);
     const fields={username:text(body.username,40),email:text(body.email,254),phone:text(body.phone,30),password:typeof body.password==='string'?body.password:'',confirm:typeof body.confirm==='string'?body.confirm:'',privacyRead:body.privacyRead===true,processingConsent:body.processingConsent===true,termsAccepted:body.termsAccepted===true};
     const errors=validateAuthForm('signup',fields);if(Object.keys(errors).length)fail(400,'Üyelik başvurusu tamamlanamadı. Zorunlu alanları ve onayları kontrol edin.',errors);
     if(state.users.some(user=>canonical(user.username)===canonical(fields.username)||user.email.toLowerCase()===fields.email.toLowerCase()))fail(409,'Bu kullanıcı adı veya e-posta ile daha önce başvuru yapılmış.');
     const user={id:randomUUID(),username:fields.username,displayName:fields.username,email:fields.email.toLowerCase(),phone:fields.phone,passwordHash:await hashPassword(fields.password),role:'member',status:'pending',createdAt:iso,consent:{version:POLICY_VERSION,at:iso,privacyRead:true,processingConsent:true,termsAccepted:true}};state.users.push(user);notify(state,'membership',user.id,`${user.username} üyelik onayı bekliyor.`);
     return respond(201,{message:'Başvurunuz alındı. Yönetici onayından sonra giriş yapabilirsiniz.'});
    }
    if(route==='/auth/login'&&method==='POST'){
     limit(state,'login:'+digest(ip),20,15*60_000,time);
     const name=text(body.username,254);const user=state.users.find(row=>canonical(row.username)===canonical(name)||row.email.toLowerCase()===name.toLowerCase());
     dummyHash ||= await hashPassword(randomBytes(24).toString('hex'));
     const valid=await matches(typeof body.password==='string'?body.password:'',user?.passwordHash||dummyHash);if(!user||!valid)fail(401,'Kullanıcı adı veya şifre hatalı.');
     if(user.status!=='active')fail(403,user.status==='pending'?'Üyeliğiniz yönetici onayı bekliyor.':user.status==='suspended'?'Üyeliğiniz pasif durumda. Yöneticiyle iletişime geçin.':'Üyeliğiniz iptal edilmiş veya başvurunuz reddedilmiş.');
     if(identity)state.sessions=state.sessions.filter(row=>row!==identity.session);
     outputToken=newSession(state,user,time);return respond(200,{user:publicUser(user),message:'Giriş yapıldı.'},outputToken);
    }
    if(route==='/auth/logout'&&method==='POST'){if(identity)state.sessions=state.sessions.filter(row=>row!==identity.session);return respond(200,{message:'Çıkış yapıldı.'},'');}
    if(route==='/auth/reset'&&method==='POST')return respond(200,{message:'Otomatik şifre sıfırlama e-postası henüz bağlı değil. İletişim sayfasından yöneticiye ulaşabilirsiniz.'});
    if(route==='/account'&&method==='PATCH'){
     const user=requireUser();limit(state,'account:'+user.id,15,15*60_000,time);if(!await matches(body.currentPassword||'',user.passwordHash))fail(400,'Değişiklik için mevcut şifrenizi doğru girin.');
     const email=text(body.email,254),phone=text(body.phone,30),displayName=text(body.displayName||user.displayName,80);
     if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||email.length>254||!validPhone(phone)||displayName.length<2||displayName.length>80)fail(400,'Geçerli ad, e-posta ve telefon bilgilerini girin.');
     if(state.users.some(row=>row.id!==user.id&&row.email.toLowerCase()===email.toLowerCase()))fail(409,'Bu e-posta başka bir hesapta kullanılıyor.');
     if(body.newPassword){if(typeof body.newPassword!=='string'||body.newPassword.length<8||body.newPassword.length>128||body.newPassword!==body.confirmPassword)fail(400,'Yeni şifre 8–128 karakter olmalı ve tekrarıyla eşleşmeli.');user.passwordHash=await hashPassword(body.newPassword);revoke(state,user.id);outputToken=newSession(state,user,time);}
     Object.assign(user,{email:email.toLowerCase(),phone,displayName});return respond(200,{user:publicUser(user),profile:ownProfile(state),message:'Hesap bilgileriniz güncellendi.'},outputToken);
    }
    if(route==='/account/delete'&&method==='POST'){
     const user=requireUser();limit(state,'delete:'+user.id,10,15*60_000,time);if(user.role==='admin')fail(400,'Tek yönetici hesabı bu ekrandan silinemez.');
     if(body.confirmation!=='HESABIMI SİL'||!await matches(body.password||'',user.passwordHash))fail(400,'Şifrenizi ve HESABIMI SİL onayını kontrol edin.');
     const removedOrders=new Set(state.orders.filter(order=>order.userId===user.id).map(order=>order.id));state.users=state.users.filter(row=>row.id!==user.id);revoke(state,user.id);state.orders=state.orders.filter(order=>order.userId!==user.id);state.notifications=state.notifications.filter(row=>row.ref!==user.id&&!removedOrders.has(row.ref));return respond(200,{message:'Hesabınız ve bu aşamadaki sipariş talepleriniz silindi.'},'');
    }
    if(route==='/orders'&&method==='GET'){const user=requireUser();return respond(200,{orders:state.orders.filter(order=>order.userId===user.id).toReversed()});}
    if(route==='/orders'&&method==='POST'){
     const user=requireUser();limit(state,'order:'+user.id,10,3600_000,time);
     const type=ORDER_TYPES.find(row=>row.id===body.type),description=text(body.description,4000),key=text(body.requestId,60);
     if(!type||description.length<10||description.length>4000||!/^[a-zA-Z0-9-]{16,60}$/.test(key))fail(400,'Yazılım türünü ve 10–4000 karakterlik kısa açıklamanızı girin.');
     const existing=state.orders.find(order=>order.userId===user.id&&order.requestId===key);if(existing)return respond(200,{order:existing,message:'Talebiniz daha önce kaydedildi.'});
     const order={id:randomUUID(),number:`BB-${new Date(time).getFullYear()}-${String(state.nextOrder++).padStart(5,'0')}`,userId:user.id,requestId:key,type:type.id,typeLabel:type.label,estimate:type.price,description,status:'received',createdAt:iso,history:[{status:'received',note:'Talebiniz yöneticiye iletildi.',at:iso}]};state.orders.push(order);notify(state,'order',order.id,`${order.number} · ${user.username} yeni sipariş talebi gönderdi.`);return respond(201,{order,message:'Talebiniz alındı. Siparişlerim bölümünden takip edebilirsiniz.'});
    }
    if(route==='/admin/notifications'&&method==='GET'){requireAdmin();return respond(200,{notifications:state.notifications.slice(0,100),unread:state.notifications.filter(row=>!row.read).length,pending:state.users.filter(row=>row.status==='pending').length});}
    if(route==='/admin/notifications/read'&&method==='POST'){requireAdmin();state.notifications.forEach(row=>row.read=true);return respond(200,{message:'Bildirimler okundu olarak işaretlendi.'});}
    if(route==='/admin/members'&&method==='GET'){requireAdmin();return respond(200,{members:state.users.filter(row=>row.id!==state.ownerId).map(publicUser).toReversed()});}
    const memberMatch=route.match(/^\/admin\/members\/([a-z0-9-]+)$/i);
    if(memberMatch&&method==='PATCH'){
     requireAdmin();const user=state.users.find(row=>row.id===memberMatch[1]&&row.id!==state.ownerId);if(!user)fail(404,'Üye bulunamadı.');
     const actions={approve:'active',reject:'rejected',suspend:'suspended',activate:'active',cancel:'cancelled'};if(!Object.hasOwn(actions,body.action))fail(400,'Üyelik işlemi geçersiz.');const status=actions[body.action];
     if(['approve','reject'].includes(body.action)&&user.status!=='pending')fail(409,'Bu başvuru artık onay beklemiyor.');
     user.status=status;user.updatedAt=iso;if(status!=='active')revoke(state,user.id);return respond(200,{member:publicUser(user),message:'Üyelik durumu güncellendi.'});
    }
    if(route==='/admin/orders'&&method==='GET'){requireAdmin();return respond(200,{orders:state.orders.map(order=>({...order,customer:publicUser(state.users.find(user=>user.id===order.userId))})).toReversed()});}
    const orderMatch=route.match(/^\/admin\/orders\/([a-z0-9-]+)$/i);
    if(orderMatch&&method==='PATCH'){
     requireAdmin();const order=state.orders.find(row=>row.id===orderMatch[1]);if(!order)fail(404,'Sipariş bulunamadı.');if(!Object.hasOwn(ORDER_STATUSES,body.status))fail(400,'Sipariş durumu geçersiz.');const note=text(body.note,1000);if(note.length>1000)fail(400,'Açıklama çok uzun.');if(order.status!==body.status||note){order.status=body.status;order.history.push({status:body.status,note,at:iso});}return respond(200,{order,message:'Sipariş durumu güncellendi.'});
    }
    fail(404,'İşlem bulunamadı.');
   }catch(error){return respond(error.status||500,{error:error.status?error.message:'İşlem tamamlanamadı.',...(error.fields?{fields:error.fields}:{})});}
  });}catch{return respond(503,{error:'Üyelik hizmetine şu anda ulaşılamıyor. Lütfen daha sonra tekrar deneyin.'});}
 };
}
