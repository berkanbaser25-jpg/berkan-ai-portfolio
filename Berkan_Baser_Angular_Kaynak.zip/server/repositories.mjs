import { mkdir } from 'node:fs/promises';
import path from 'node:path';

export const emptyState=()=>({version:1,users:[],sessions:[],orders:[],notifications:[],limits:[],ownerId:null,nextOrder:1});

// SQLite transactions keep the local state durable, including concurrent requests.
export async function localRepository(filename){
 const {DatabaseSync}=await import('node:sqlite');
 await mkdir(path.dirname(filename),{recursive:true});
 const db=new DatabaseSync(filename);db.exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000; CREATE TABLE IF NOT EXISTS portal (id INTEGER PRIMARY KEY CHECK(id=1), body TEXT NOT NULL)');
 let queue=Promise.resolve();
 return {
  hasOwner(){return Boolean(JSON.parse(db.prepare('SELECT body FROM portal WHERE id=1').get()?.body||'{}').ownerId);},
  transact(callback){const operation=queue.then(async()=>{db.exec('BEGIN IMMEDIATE');try{const state=JSON.parse(db.prepare('SELECT body FROM portal WHERE id=1').get()?.body||JSON.stringify(emptyState()));const before=JSON.stringify(state);const result=await callback(state);const body=JSON.stringify(state);if(before!==body)db.prepare('INSERT INTO portal(id,body) VALUES(1,?) ON CONFLICT(id) DO UPDATE SET body=excluded.body').run(body);db.exec('COMMIT');return result;}catch(error){db.exec('ROLLBACK');throw error;}});queue=operation.catch(()=>{});return operation;},
  async close(){await queue;db.close();}
 };
}

// A site-wide store survives deploys. ETag compare-and-set prevents lost updates.
export async function blobRepository(){
 const {getStore}=await import('@netlify/blobs');
 const store=getStore({name:'berkan-portal-v1',consistency:'strong',region:process.env.BLOBS_REGION||'eu-central-1'});
 return {
  async transact(callback){
   for(let attempt=0;attempt<8;attempt++){
    const entry=await store.getWithMetadata('private-state',{type:'json',consistency:'strong'});
    const state=entry?.data||emptyState(),before=JSON.stringify(state),result=await callback(state);
    if(before===JSON.stringify(state))return result;
    const written=await store.setJSON('private-state',state,entry?{onlyIfMatch:entry.etag}:{onlyIfNew:true});
    if(written.modified)return result;
   }
   throw new Error('Concurrent write retry limit');
  }
 };
}
