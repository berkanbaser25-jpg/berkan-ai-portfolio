import http from 'node:http';
import {createReadStream} from 'node:fs';
import {stat} from 'node:fs/promises';
import path from 'node:path';
import {createPortal} from './portal.mjs';

export function applicationServer({repository,adminPassword,staticRoot}){
 const api=createPortal(repository,{adminPassword});
 const mime={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.wasm':'application/wasm','.pdf':'application/pdf','.csv':'text/csv; charset=utf-8','.ipynb':'application/x-ipynb+json'};
 return http.createServer(async(req,res)=>{
  try{
   const url=new URL(req.url,'http://'+req.headers.host);
   if(url.pathname.startsWith('/api/')){
    const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>32_000){res.writeHead(413);res.end();return;}chunks.push(chunk);}const body=Buffer.concat(chunks).toString('utf8');
    const request=new Request(url,{method:req.method,headers:req.headers,...(req.method!=='GET'&&req.method!=='HEAD'?{body}:{} )});
    const response=await api(request,{ip:req.socket.remoteAddress||'local'});res.writeHead(response.status,Object.fromEntries(response.headers));res.end(Buffer.from(await response.arrayBuffer()));return;
   }
   const root=path.resolve(staticRoot),pathname=decodeURIComponent(url.pathname);let file=path.resolve(root,'.'+pathname);
   if(file!==root&&!file.startsWith(root+path.sep)){res.writeHead(403);res.end();return;}
   let info=await stat(file).catch(()=>null);
   if(!info?.isFile()){
    if(path.extname(pathname)){res.writeHead(404);res.end('Not found');return;}
    file=path.join(root,'index.html');info=await stat(file);
   }
   res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream','Content-Length':info.size,'Cache-Control':'no-cache','X-Content-Type-Options':'nosniff'});createReadStream(file).pipe(res);
  }catch{res.writeHead(500);res.end('Server error');}
 });
}
