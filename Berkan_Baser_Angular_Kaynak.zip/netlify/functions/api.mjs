import {blobRepository} from '../../server/repositories.mjs';
import {createPortal} from '../../server/portal.mjs';
let handle;
export default async(request,context)=>{
 handle ||= createPortal(await blobRepository(),{adminPassword:process.env.ADMIN_INITIAL_PASSWORD||''});
 return handle(request,{ip:context.ip||'unknown'});
};
// /api/* is rewritten to the default function URL by netlify.toml/_redirects.
// A custom config.path would disable that default URL and break the rewrite.
