import assert from 'node:assert/strict';
import {answerSupport} from '../src/app/core/support-engine.mjs';
const cases=[
 ['Selam','welcome'],['Bir web sitesi yaptırsam bütçem ne olur?','price-website'],
 ['Otomasyon için ücret nedir?','price-software'],['Yapay zeka yaptırmak istiyorum fiyatı nedir?','price-ai'],
 ['Fiyatlarınız nedir?','pricing'],['Kayıt yaptırmak istiyorum','signup'],
 ['Üye oldum ama giriş yapamıyorum','approval'],['Parolamı hatırlamıyorum','password'],
 ['Siparişim ne durumda?','tracking'],['Hesabımı kapatmak istiyorum','delete'],
 ['Market projesini anlatır mısın?','market'],['Kavşak uygulamanız nedir?','junction'],
 ['Mail adresinizi öğrenebilir miyim?','contact'],['Telefon numarası nedir?','contact'],
 ['Mesajlar saklanıyor mu?','privacy'],['Ne zaman teslim edersiniz?','delivery'],
 ['Hangi ödeme yöntemleri var?','payment'],['Demolar ücretli mi?','demos'],
 ['İstanbul yarın hava nasıl?','fallback'],['Uçak bileti fiyatı nedir?','fallback'],
 ['Bana yemek tarifi ver','fallback'],['<script>alert(1)</script>','fallback'],
 ['xyzxyzxyz','fallback'],['','fallback'],['MARKET NASIL KULLANILIR','market-guide'],
 ['Kavşak raporu','junction-docs'],['Market raporu','market-docs']
];
for(const[query,id]of cases)assert.equal(answerSupport(query).id,id,query);
assert.equal(answerSupport('Nasıl kullanırım?',{topic:'market'}).id,'market-guide');
assert.equal(answerSupport('Raporunu aç',{topic:'junction'}).id,'junction-docs');
assert.equal(answerSupport('Gerçek veri mi?',{topic:'market'}).id,'market-data');
assert.equal(answerSupport('Kavşak projesi nedir?',{topic:'market'}).id,'junction');
assert.equal(answerSupport('Fiyatı nedir?',{topic:'website'}).id,'price-website');
assert.equal(answerSupport('Fiyatı nedir?',{topic:'market'}).id,'pricing');
const contact=answerSupport('İletişim bilgileri',{profile:{displayName:'Örnek Yönetici',email:'sample@example.com',phone:'+90 555 000 00 00'}});
assert.match(contact.text,/sample@example.com/);assert.match(contact.text,/Örnek Yönetici/);
const custom=answerSupport('web fiyatı',{orderTypes:[{id:'ai',price:'A'},{id:'website',price:'GÜNCEL BÜTÇE'},{id:'software',price:'C'}]});assert.match(custom.text,/GÜNCEL BÜTÇE/);
for(const[query]of cases){const answer=answerSupport(query);for(const action of answer.actions)if(action.kind==='route')assert.match(action.path,/^\/(projeler\/(market|kavsak)|siparis-ver|siparislerim|hesap|hakkimda)$/);assert.doesNotMatch(answer.text,/\{price_|\{owner\}|\{email\}/);}
console.log('PASS: 27 question cases, topic follow-ups, subject changes, current profile/budgets, fallback and trusted page links.');
