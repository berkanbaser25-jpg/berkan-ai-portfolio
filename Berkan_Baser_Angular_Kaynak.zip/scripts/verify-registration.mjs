import assert from 'node:assert/strict';
import {validateAuthForm,validPhone} from '../src/app/core/auth-validation.ts';

const valid={username:'deneme',email:'demo@example.com',phone:'+90 532 000 00 00',password:'Deneme-123!',confirm:'Deneme-123!',privacyRead:true,processingConsent:true,termsAccepted:true};
assert.deepEqual(validateAuthForm('signup',valid),{});
for(const field of ['username','email','phone','password','confirm']){
 assert.ok(validateAuthForm('signup',{...valid,[field]:''})[field],field+' must be mandatory');
}
for(const field of ['username','email','phone']){
 assert.ok(validateAuthForm('signup',{...valid,[field]:'   '})[field],field+' cannot contain only whitespace');
}
for(const field of ['privacyRead','processingConsent','termsAccepted']){
 assert.ok(validateAuthForm('signup',{...valid,[field]:false})[field],field+' must be accepted');
 assert.ok(validateAuthForm('signup',{...valid,[field]:'false'})[field],field+' must be true, not truthy');
}
assert.ok(validateAuthForm('signup',{...valid,email:'gecersiz@'})['email']);
assert.ok(validateAuthForm('signup',{...valid,phone:'telefon 0532 000 00 00'})['phone']);
assert.ok(validateAuthForm('signup',{...valid,password:'kisa',confirm:'kisa'})['password']);
assert.ok(validateAuthForm('signup',{...valid,confirm:'Farkli-123!'})['confirm']);
for(const value of ['0532 000 00 00','(532) 000-00-00','+90 (532) 000 00 00','0090 532 000 00 00','+1 415 555 2671'])assert.ok(validPhone(value),value);
for(const value of ['000','12345','+90++5320000000','abc05320000000','+000000000','+1234567890123456'])assert.equal(validPhone(value),false,value);
assert.deepEqual(validateAuthForm('login',{...valid,email:'',phone:'',privacyRead:false,processingConsent:false}),{});
assert.deepEqual(validateAuthForm('reset',{...valid,username:'',password:'',confirm:'',phone:'',privacyRead:false,processingConsent:false}),{});
assert.ok(validateAuthForm('login',{...valid,password:''}).password);
assert.ok(validateAuthForm('reset',{...valid,email:''}).email);
console.log('PASS: required identity/contact fields, explicit consent, phone/email formats, passwords and login/reset separation.');
