import {mkdir,readFile,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomBytes} from 'node:crypto';
import {localRepository} from '../server/repositories.mjs';
import {applicationServer} from '../server/http-server.mjs';
const root=path.resolve(fileURLToPath(new URL('../',import.meta.url))),privateRoot=path.join(root,'.runtime');
await mkdir(privateRoot,{recursive:true});
const repository=await localRepository(path.join(privateRoot,'portal.sqlite'));
let password=process.env.ADMIN_INITIAL_PASSWORD||'';
if(!repository.hasOwner()&&!password){
 const credentialsFile=path.join(privateRoot,'yonetici-ilk-giris.json');
 let credentials=await readFile(credentialsFile,'utf8').then(JSON.parse).catch(()=>null);
 if(!credentials){credentials={url:'http://127.0.0.1:4200/',username:'berkan',password:randomBytes(24).toString('base64url'),note:'İlk giriş bilgisidir. Hesap ayarlarından şifrenizi değiştirin. Bu dosyayı paylaşmayın.'};await writeFile(credentialsFile,JSON.stringify(credentials,null,2),{mode:0o600});}
 password=credentials.password;
}
const server=applicationServer({repository,adminPassword:password,staticRoot:path.join(root,'dist/portfolio/browser')});
server.listen(Number(process.env.PORT)||4200,'127.0.0.1',()=>console.log('Portfolio: http://127.0.0.1:4200/ · Yönetici ilk giriş dosyası .runtime içinde (yayına dahil edilmez).'));
process.on('SIGTERM',()=>server.close(async()=>{await repository.close();process.exit(0);}));
