import { copyFile } from 'node:fs/promises';
await copyFile(new URL('../dist/portfolio/3rdpartylicenses.txt',import.meta.url),new URL('../dist/portfolio/browser/3rdpartylicenses.txt',import.meta.url));
