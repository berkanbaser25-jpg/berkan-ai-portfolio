import { bootstrapApplication } from '@angular/platform-browser';
import { provideRouter, withInMemoryScrolling } from '@angular/router';
import { AppComponent } from './app/app.component';

bootstrapApplication(AppComponent, { providers: [provideRouter([
  { path: '', loadComponent: () => import('./app/pages/home.component').then(m => m.HomeComponent), title: 'Berkan Başer — Yapay zekâ ve web geliştirme' },
  { path: 'projeler/market', loadComponent: () => import('./app/pages/market.component').then(m => m.MarketComponent), title: 'Market Planlayıcı | Berkan Başer' },
  { path: 'projeler/kavsak', loadComponent: () => import('./app/pages/junction.component').then(m => m.JunctionComponent), title: 'Kavşak Laboratuvarı | Berkan Başer' },
  { path: 'hakkimda', loadComponent: () => import('./app/pages/about.component').then(m => m.AboutComponent), title: 'Hakkımda ve iletişim | Berkan Başer' },
  { path: 'siparis-ver', loadComponent: () => import('./app/pages/order.component').then(m => m.OrderComponent), title: 'Sipariş ver' },
  { path: 'siparislerim', loadComponent: () => import('./app/pages/orders.component').then(m => m.OrdersComponent), title: 'Siparişlerim' },
  { path: 'hesap', loadComponent: () => import('./app/pages/account.component').then(m => m.AccountComponent), title: 'Hesap ayarları' },
  { path: 'yonetim', loadComponent: () => import('./app/pages/admin.component').then(m => m.AdminComponent), title: 'Yönetim' },
  { path: '**', redirectTo: '' }
], withInMemoryScrolling({ scrollPositionRestoration: 'enabled', anchorScrolling: 'enabled' }))] }).catch(console.error);
