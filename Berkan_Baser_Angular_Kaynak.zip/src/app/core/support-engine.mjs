import {SUPPORT_KNOWLEDGE} from './support-knowledge.mjs';
import {DEFAULT_OWNER,ORDER_TYPES} from './portal-config.mjs';

const normalize=text=>String(text).toLocaleLowerCase('tr-TR').replaceAll('ı','i').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9\s]/g,' ').replace(/\s+/g,' ').trim();
const stop=new Set('bir bu şu su o ben benim bana bize biz siz sizin bana mı mi mu mü ne nedir nasil icin ile ve veya de da da mi acaba acaba lutfen istiyorum istiyoruz istedim öğrenmek ogrenmek bilgi hakkında hakkinda biraz olarak cok daha bana yardımcı yardimci olur olabilir misin musun misiniz musunuz miyim anlatir anlatabilir anlatirmisin ogrenebilir ogrenebilirmiyim soyleyebilir hangi kadar kaç kac var olan'.split(' '));
const canonical=word=>/^proje/.test(word)?'proje':/^adres/.test(word)?'adres':/^mesaj/.test(word)?'mesaj':/^uygulama/.test(word)?'uygulama':/^demo/.test(word)?'demo':word==='mail'?'posta':({fiyati:'fiyat',fiyatlar:'fiyat',fiyatlari:'fiyat',ucreti:'ucret',ucretler:'ucret',uyelik:'uye',uyeligim:'uye',uyeligimi:'uye',uyeligime:'uye',uyeligimin:'uye',uyeligi:'uye',uyeligini:'uye',sifrem:'sifre',sifremi:'sifre',sifreni:'sifre',sifremle:'sifre',parola:'sifre',parolami:'sifre',sitem:'site',sitesi:'site',sitesine:'site',siteniz:'site',sitenizin:'site',projesi:'proje',projeyi:'proje',projeleri:'proje',projelerin:'proje',projesinde:'proje',verileri:'veri',veriler:'veri',verilerin:'veri',siparisim:'siparis',siparisimi:'siparis',siparisimin:'siparis',talebim:'talep',talebimi:'talep',talebimin:'talep',hesabim:'hesap',hesabimi:'hesap',hesabima:'hesap',hesabimin:'hesap',maliyeti:'maliyet',raporu:'rapor',raporunu:'rapor',raporlar:'rapor',kavsagi:'kavsak',kavsaktaki:'kavsak',websitesi:'website',websitsi:'website',algoritmasi:'algoritma',algoritmayi:'algoritma'}[word]||word);
const words=text=>normalize(text).split(' ').filter(word=>word.length>1&&!stop.has(word)).map(canonical);
function features(text){
 const tokens=words(text),map=new Map();
 for(const word of tokens){map.set('w:'+word,(map.get('w:'+word)||0)+1);const padded='^'+word+'$';for(let i=0;i<padded.length-2;i++){const key='c:'+padded.slice(i,i+3);map.set(key,(map.get(key)||0)+.16);}}
 return map;
}
const documents=SUPPORT_KNOWLEDGE.flatMap(record=>record.questions.map(question=>({record,features:features(question)})));
const frequencies=new Map();for(const doc of documents)for(const key of doc.features.keys())frequencies.set(key,(frequencies.get(key)||0)+1);
const idf=key=>Math.log((documents.length+1)/((frequencies.get(key)||0)+1))+1;
function vector(features){const map=new Map();let norm=0;for(const[key,count]of features){const value=count*idf(key);map.set(key,value);norm+=value*value;}norm=Math.sqrt(norm)||1;for(const[key,value]of map)map.set(key,value/norm);return map;}
for(const doc of documents)doc.vector=vector(doc.features);
const vocabulary=new Set(documents.flatMap(doc=>[...doc.features.keys()].filter(key=>key.startsWith('w:')).map(key=>key.slice(2))));
const byId=id=>SUPPORT_KNOWLEDGE.find(record=>record.id===id);
const priceQuestion=text=>/fiyat|ucret|butce|maliyet|kac para|ne kadar/.test(text);
function render(record,profile,orderTypes){
 const replacements={owner:profile.displayName,email:profile.email,phone:profile.phone,...Object.fromEntries(orderTypes.map(type=>['price_'+type.id,type.price]))};
 return{id:record.id,topic:record.topic,source:record.title,text:record.text.replace(/\{([^}]+)\}/g,(_,key)=>replacements[key]||''),actions:record.actions||[],suggestions:record.suggestions||[],matched:true};
}
export function answerSupport(query,{topic='',profile=DEFAULT_OWNER,orderTypes=ORDER_TYPES}={}){
 const raw=normalize(query),tokens=words(query),known=tokens.filter(word=>vocabulary.has(word)).length;
 const reply=record=>render(record,profile,orderTypes);
 // Sadece kısa takip soruları önceki konuya bağlanır; açık konu değişimi önceliklidir.
 const explicit=/market|kavsak|arac|kamera|plaka|web|internet|site yaptir|otomasyon|ozel program|yapay zeka/.test(raw);
 if(!explicit&&tokens.length<=5&&['market','junction'].includes(topic)){
  if(/rapor|ipynb|dokuman|ozet/.test(raw))return reply(byId(topic==='market'?'market-docs':'junction-docs'));
  if(/nasil kullan|nasil dene/.test(raw))return reply(byId(topic==='market'?'market-guide':'junction-guide'));
  if(/veri|gercek|dogruluk|mape/.test(raw))return reply(byId(topic==='market'?'market-data':'junction-data'));
 }
 if(/demo|proje.*dene|uygulama.*dene/.test(raw)&&/ucret|fiyat|odeme|ucretsiz/.test(raw))return reply(byId('demos'));
 if(priceQuestion(raw)&&!(known<=1&&tokens.length-known>=2)){
  const website=/web|internet|site yaptir|site fiyat/.test(raw),ai=/yapay zeka|\bai\b|tahmin model|goruntu isleme/.test(raw),software=/ozel program|masaustu|otomasyon|is takip/.test(raw);
  if(Number(website)+Number(ai)+Number(software)===1)return reply(byId(website?'price-website':ai?'price-ai':'price-software'));
  if(!explicit&&['website','ai','software'].includes(topic))return reply(byId('price-'+topic));
  return reply(byId('pricing'));
 }
 const queryVector=vector(features(query)),ranks=new Map();
 for(const doc of documents){let score=0;for(const[key,value]of queryVector)score+=value*(doc.vector.get(key)||0);if(score>(ranks.get(doc.record.id)?.score||0))ranks.set(doc.record.id,{record:doc.record,score});}
 const best=[...ranks.values()].sort((a,b)=>b.score-a.score)[0];
 if(best&&best.score>=.34&&!(known<=1&&tokens.length-known>=2))return reply(best.record);
 return{id:'fallback',topic,source:'Konuyu netleştirelim',matched:false,text:'Bu soruyu site bilgilerimizle yeterince eşleştiremedim. Market projesi, kavşak projesi, fiyatlar veya üyelikten hangisini soruyorsun? Konu bunların dışındaysa doğrudan iletişime geçebilirsin.',actions:[{label:'E-posta ile ulaş',kind:'email'}],suggestions:['Projeleri tanıt','Fiyat aralıkları','Nasıl üye olurum?','İletişim bilgileri']};
}
