export const DEFAULT_OWNER={displayName:'Berkan Başer',email:'berkanbaser25@gmail.com',phone:'+90 532 371 51 05'};
export const POLICY_VERSION='2026-11-24-v2';
export const MEMBERSHIP_TERMS='Hakaret, taciz, tehdit, kaba veya kötü davranışlar ve hizmetin kötüye kullanılması üyeliğin askıya alınmasına veya iptaline neden olabilir. Bu durumlarda, yürürlükteki mevzuat ve mevcut siparişlerden doğan hak ve yükümlülükler saklı kalmak üzere, önceden bildirim yapılmadan üyelik erişimi sonlandırılabilir.';
export const ORDER_TYPES=[
 {id:'ai',label:'Yapay zekâ algoritması',price:'50.000 TL – 5.000.000 TL',description:'Tahmin, görüntü işleme, veri analizi veya yapay zekâ entegrasyonu.'},
 {id:'website',label:'İnternet sitesi',price:'5.000 TL – 500.000 TL',description:'Tanıtım sitesi, kurumsal web deneyimi veya özel web platformu.'},
 {id:'software',label:'İsteğe özel program',price:'50.000 TL ve üzeri',description:'İş akışına özel masaüstü uygulaması, otomasyon veya yönetim programı.'}
];
export const ORDER_STATUSES={received:'Talep alındı',reviewing:'İnceleniyor',proposal:'Teklif hazır',developing:'Geliştiriliyor',completed:'Tamamlandı',cancelled:'İptal edildi'};
export const MEMBER_STATUSES={pending:'Onay bekliyor',active:'Aktif',suspended:'Pasif',cancelled:'Üyeliği iptal edildi',rejected:'Başvuru reddedildi'};
