import { Component, DestroyRef, ElementRef, ViewChild, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { validateAuthForm, type AuthMode, type AuthField } from './auth-validation';
import {PortalService,PortalError} from './portal.service';
import {MEMBERSHIP_TERMS} from './portal-config.mjs';

@Component({
 selector:'app-auth-dialog',standalone:true,imports:[FormsModule],
 styleUrl:'./auth-dialog.component.css',
 template:`
 <dialog #dialog class="auth-dialog" [class.auth-dialog--signup]="mode()==='signup'" aria-labelledby="auth-title" aria-describedby="auth-description" (click)="onBackdropClick($event)" (close)="onClosed()">
  <div class="auth-close-bar">
   <button class="auth-close" type="button" aria-label="Üyelik penceresini kapat" (click)="close()"><svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg></button>
  </div>
  <div class="auth-content">
   <div class="auth-emblem" aria-hidden="true"><svg viewBox="0 0 24 24" width="24" height="24"><circle cx="12" cy="8" r="3.5"/><path d="M5 21v-2a7 7 0 0 1 14 0v2"/></svg></div>
   <p class="auth-eyebrow">{{portal.profile().displayName.toLocaleUpperCase('tr')}} · ÜYELİK</p>
   <h2 id="auth-title">{{mode()==='reset'?'Şifreni yenile':mode()==='signup'?'Aramıza katıl.':'Tekrar merhaba.'}}</h2>
   <p id="auth-description">{{mode()==='reset'?'Hesabına bağlı e-posta adresini yaz.':mode()==='signup'?'Yeni bir hesap için bilgilerini doldur.':'Devam etmek için hesabına giriş yap.'}}</p>
   @if(mode()!=='reset'){
    <div class="auth-switch" role="group" aria-label="Üyelik işlemi">
     <button type="button" [class.selected]="mode()==='login'" [attr.aria-pressed]="mode()==='login'" (click)="switchMode('login')">Giriş yap</button>
     <button type="button" [class.selected]="mode()==='signup'" [attr.aria-pressed]="mode()==='signup'" (click)="switchMode('signup')">Üye ol</button>
    </div>
   }
   <form novalidate (ngSubmit)="submit()">
    @if(message()){<p id="auth-feedback" class="auth-message" [class.is-error]="isError()" [attr.role]="isError()?'alert':'status'" tabindex="-1">{{message()}}</p>}
    <div class="auth-fields" [class.auth-fields--signup]="mode()==='signup'">
    @if(mode()!=='reset'){
     <div class="auth-field">
     <label for="auth-username">Kullanıcı adı</label>
     <input id="auth-username" name="username" [(ngModel)]="username" autocomplete="username" placeholder="Kullanıcı adını yaz" required [minLength]="mode()==='signup'?3:1" maxlength="40" autocapitalize="none" spellcheck="false" [class.field-invalid]="errors().username" [attr.aria-invalid]="!!errors().username" [attr.aria-describedby]="errors().username?'auth-username-error':null" (input)="clearError('username')">
     @if(errors().username){<p id="auth-username-error" class="auth-field-error">{{errors().username}}</p>}
     </div>
    }
    @if(mode()!=='login'){
     <div class="auth-field">
     <label for="auth-email">{{mode()==='signup'?'İletişim e-postası':'E-posta adresi'}}</label>
     <input id="auth-email" name="email" [(ngModel)]="email" type="email" autocomplete="email" placeholder="ornek@eposta.com" required maxlength="254" [class.field-invalid]="errors().email" [attr.aria-invalid]="!!errors().email" [attr.aria-describedby]="errors().email?'auth-email-error':null" (input)="clearError('email')">
     @if(errors().email){<p id="auth-email-error" class="auth-field-error">{{errors().email}}</p>}
     </div>
    }
    @if(mode()==='signup'){
     <div class="auth-field auth-field--wide">
     <label for="auth-phone">Telefon numarası</label>
     <input id="auth-phone" name="phone" [(ngModel)]="phone" type="tel" inputmode="tel" autocomplete="tel" placeholder="+90 532 000 00 00" required maxlength="30" [class.field-invalid]="errors().phone" [attr.aria-invalid]="!!errors().phone" [attr.aria-describedby]="errors().phone?'auth-phone-error':null" (input)="clearError('phone')">
     @if(errors().phone){<p id="auth-phone-error" class="auth-field-error">{{errors().phone}}</p>}
     </div>
    }
    @if(mode()!=='reset'){
     <div class="auth-field">
     <label for="auth-password">Şifre</label>
     <input id="auth-password" name="password" [(ngModel)]="password" type="password" [attr.autocomplete]="mode()==='login'?'current-password':'new-password'" [placeholder]="mode()==='signup'?'En az 8 karakter':'Şifreni yaz'" required [minLength]="mode()==='signup'?8:1" maxlength="128" [class.field-invalid]="errors().password" [attr.aria-invalid]="!!errors().password" [attr.aria-describedby]="errors().password?'auth-password-error':null" (input)="clearError('password')">
     @if(errors().password){<p id="auth-password-error" class="auth-field-error">{{errors().password}}</p>}
     </div>
    }
    @if(mode()==='signup'){
     <div class="auth-field">
     <label for="auth-confirm">Şifre tekrar</label>
     <input id="auth-confirm" name="confirm" [(ngModel)]="confirm" type="password" autocomplete="new-password" placeholder="Şifreni tekrar yaz" required minlength="8" maxlength="128" [class.field-invalid]="errors().confirm" [attr.aria-invalid]="!!errors().confirm" [attr.aria-describedby]="errors().confirm?'auth-confirm-error':null" (input)="clearError('confirm')">
     @if(errors().confirm){<p id="auth-confirm-error" class="auth-field-error">{{errors().confirm}}</p>}
     </div>
    }
    </div>
    @if(mode()==='signup'){
     <details class="auth-privacy-notice"><summary>KVKK Aydınlatma Metni</summary><div>
      <p><b>Formu sunan:</b> {{portal.profile().displayName}}. İletişim: {{portal.profile().email}}.</p>
      <p><b>Bilgiler ve amaç:</b> Kullanıcı adı, iletişim e-postası ve telefon numarası üyelik başvurusunun değerlendirilmesi ve başvuruya ilişkin iletişim amacıyla istenir. Şifre yalnızca form kontrolüne tabidir.</p>
      <p><b>Kayıt ve kullanım:</b> Başvuru gönderildiğinde üyelik, iletişim ve onay bilgileriniz hesabın yönetimi için sunucuda saklanır. Parolanız açık metin olarak tutulmaz. Sipariş talepleriniz yalnızca size ve yöneticiye gösterilir.</p>
      <p><b>İzin ve aktarım:</b> Aşağıdaki açık rıza, bu formdaki belirtilen amaçla sınırlıdır; reklam, pazarlama veya üçüncü kişilere veri aktarım izni içermez. Aydınlatmayı okuma bildirimi ile açık rıza birbirinden ayrıdır.</p>
      <p><b>Başvuru:</b> Kişisel verilerinizle ilgili bilgi, düzeltme, silme ve rızayı geri alma taleplerinizi yukarıdaki e-posta adresine iletebilirsiniz. Hesap ayarlarından bilgilerinizi güncelleyebilir veya hesabınızı silebilirsiniz.</p>
      <p class="auth-privacy-note">Yerel kurulumda veriler bu bilgisayarda tutulur. Netlify yayını yapılırsa barındırma ve veri hizmetleri kullanılacaktır. Bu metin taslaktır; canlı yayından önce hukuki dayanak, saklama süresi ve olası yurt dışı aktarım koşulları netleştirilmelidir.</p>
     </div></details>
     <div class="auth-consents">
      <label class="auth-consent-row" [class.consent-invalid]="errors().privacyRead" for="auth-privacy-read"><input id="auth-privacy-read" name="privacyRead" type="checkbox" [(ngModel)]="privacyRead" required [attr.aria-invalid]="!!errors().privacyRead" [attr.aria-describedby]="errors().privacyRead?'auth-privacy-error':null" (ngModelChange)="clearError('privacyRead')"><span>KVKK Aydınlatma Metni’ni okudum.</span></label>
      @if(errors().privacyRead){<p id="auth-privacy-error" class="auth-field-error">{{errors().privacyRead}}</p>}
      <label class="auth-consent-row" [class.consent-invalid]="errors().processingConsent" for="auth-processing-consent"><input id="auth-processing-consent" name="processingConsent" type="checkbox" [(ngModel)]="processingConsent" required [attr.aria-invalid]="!!errors().processingConsent" [attr.aria-describedby]="errors().processingConsent?'auth-consent-error':null" (ngModelChange)="clearError('processingConsent')"><span>Kullanıcı adımın, e-posta ve telefon bilgilerimin belirtilen üyelik başvurusu amacıyla işlenmesine açık rıza veriyorum.</span></label>
      @if(errors().processingConsent){<p id="auth-consent-error" class="auth-field-error">{{errors().processingConsent}}</p>}
      <details class="auth-privacy-notice"><summary>Üyelik ve kullanım koşulları</summary><div><p>{{terms}}</p><p>Sipariş formları ön görüşme talepleridir. Bütçe aralıkları kesin teklif veya ödeme yükümlülüğü oluşturmaz.</p></div></details>
      <label class="auth-consent-row" [class.consent-invalid]="errors().termsAccepted" for="auth-terms"><input id="auth-terms" name="termsAccepted" type="checkbox" [(ngModel)]="termsAccepted" required [attr.aria-invalid]="!!errors().termsAccepted" (ngModelChange)="clearError('termsAccepted')"><span>Üyelik ve kullanım koşullarını kabul ediyorum.</span></label>
      @if(errors().termsAccepted){<p class="auth-field-error">{{errors().termsAccepted}}</p>}
     </div>
    }
    <div class="auth-form-actions">
     @if(mode()==='login'){<button type="button" class="auth-text-button" (click)="switchMode('reset')">Şifremi unuttum</button>}
     @else{<button type="button" class="auth-text-button" (click)="switchMode('login')">Giriş ekranına dön</button>}
     <button type="submit" class="button primary" [disabled]="busy()">{{busy()?'Lütfen bekleyin…':mode()==='reset'?'Bilgi al':mode()==='signup'?'Üye ol':'Giriş yap'}}</button>
    </div>
   </form>
   <p class="auth-availability">Yeni üyelikler yönetici onayından sonra etkinleştirilir.</p>
  </div>
 </dialog>
 `
})
export class AuthDialogComponent {
 portal=inject(PortalService);terms=MEMBERSHIP_TERMS;busy=signal(false);
 @ViewChild('dialog',{static:true}) private dialog!:ElementRef<HTMLDialogElement>;
 mode=signal<AuthMode>('login');message=signal('');isError=signal(false);errors=signal<Partial<Record<AuthField,string>>>({});
 username='';email='';phone='';password='';confirm='';privacyRead=false;processingConsent=false;termsAccepted=false;private previousOverflow='';
 constructor(){const subscription=this.portal.authRequests.subscribe(mode=>this.open(mode));inject(DestroyRef).onDestroy(()=>subscription.unsubscribe());}
 open(mode:AuthMode='login'){
  if(this.dialog.nativeElement.open)return;
  this.clearFields();this.mode.set(mode);
  this.previousOverflow=document.body.style.overflow;
  this.dialog.nativeElement.showModal();document.body.style.overflow='hidden';
  // showModal makes the rest of the page inert and keeps keyboard focus inside.
  this.focusFirstField();
 }
 close(){this.dialog.nativeElement.close();}
 onClosed(){document.body.style.overflow=this.previousOverflow;this.clearFields();}
 onBackdropClick(event:MouseEvent){
  if(event.target!==this.dialog.nativeElement)return;
  const box=this.dialog.nativeElement.getBoundingClientRect();
  if(event.clientX<box.left||event.clientX>box.right||event.clientY<box.top||event.clientY>box.bottom)this.close();
 }
 switchMode(mode:AuthMode){this.clearFields();this.mode.set(mode);this.focusFirstField();}
 private clearFields(){this.username='';this.email='';this.phone='';this.password='';this.confirm='';this.privacyRead=false;this.processingConsent=false;this.termsAccepted=false;this.errors.set({});this.message.set('');this.isError.set(false);}
 clearError(field:AuthField){const next={...this.errors()};delete next[field];this.errors.set(next);this.message.set('');this.isError.set(false);}
 private focusFirstField(){setTimeout(()=>{if(this.dialog.nativeElement.open)this.dialog.nativeElement.querySelector<HTMLInputElement>('input')?.focus();},0);}
 async submit(){
  if(this.busy())return;
  this.isError.set(false);
  const errors=validateAuthForm(this.mode(),{username:this.username,email:this.email,phone:this.phone,password:this.password,confirm:this.confirm,privacyRead:this.privacyRead,processingConsent:this.processingConsent,termsAccepted:this.termsAccepted});
  this.errors.set(errors);
  if(Object.keys(errors).length){this.isError.set(true);this.message.set(this.mode()==='signup'?'Üyelik oluşturulamadı. Lütfen kırmızıyla belirtilen zorunlu alanları ve onayları tamamlayın.':'İşlem tamamlanamadı. Lütfen belirtilen alanları kontrol edin.');setTimeout(()=>this.dialog.nativeElement.querySelector<HTMLElement>('#auth-feedback')?.focus(),0);return;}
  this.busy.set(true);
  try{
   if(this.mode()==='login'){await this.portal.login(this.username,this.password);this.close();setTimeout(()=>document.querySelector<HTMLElement>('.avatar-button')?.focus(),0);}
   else if(this.mode()==='signup'){const result:any=await this.portal.request('/auth/register','POST',{username:this.username,email:this.email,phone:this.phone,password:this.password,confirm:this.confirm,privacyRead:this.privacyRead,processingConsent:this.processingConsent,termsAccepted:this.termsAccepted});this.message.set(result.message);this.password='';this.confirm='';}
   else this.message.set('Otomatik şifre sıfırlama e-postası henüz bağlı değil. İletişim sayfasından yöneticiye ulaşabilirsiniz.');
  }catch(error){this.isError.set(true);this.message.set((error as Error).message);if(error instanceof PortalError)this.errors.set(error.fields);}
  finally{this.busy.set(false);if(this.dialog.nativeElement.open)setTimeout(()=>this.dialog.nativeElement.querySelector<HTMLElement>('#auth-feedback')?.focus(),0);}
 }
}
