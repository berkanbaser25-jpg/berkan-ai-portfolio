import {Component,ElementRef,HostListener,ViewChild,inject,signal} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {RouterLink} from '@angular/router';
import {PortalService} from './portal.service';
import {answerSupport} from './support-engine.mjs';

interface SupportAction {label:string;kind:string;path?:string;fragment?:string;mode?:string;}
interface SupportAnswer {id:string;topic:string;source:string;text:string;actions:SupportAction[];suggestions:string[];matched:boolean;}
interface ChatMessage {id:number;role:'assistant'|'user';text:string;answer?:SupportAnswer;}

@Component({selector:'app-support-chat',standalone:true,imports:[FormsModule,RouterLink],styleUrl:'./support-chat.component.css',template:`
 @if(opened()){
 <section id="support-chat" class="support-chat" role="dialog" aria-modal="false" aria-labelledby="support-chat-title">
  <header class="support-header"><span class="support-avatar" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M5 5h14v11H9l-4 4V5Z"/><path d="M8 9h8M8 12h5"/></svg></span><div><h2 id="support-chat-title">Site asistanı</h2><p>Projeler, hizmetler ve üyelik</p></div><button class="support-icon" type="button" aria-label="Konuşmayı temizle" title="Konuşmayı temizle" (click)="reset()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M4 10a8 8 0 1 1 1 7M4 4v6h6"/></svg></button><button class="support-icon" type="button" aria-label="Sohbeti kapat" (click)="close()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18"/></svg></button></header>
  <div #messagesElement class="support-messages" role="log" aria-live="polite" aria-relevant="additions" aria-label="Destek sohbeti" tabindex="0">
   @for(message of messages();track message.id){<article class="support-message" [class.from-user]="message.role==='user'"><span class="support-speaker">{{message.role==='user'?'Sen':'Site asistanı'}}</span><p>{{message.text}}</p>
    @if(message.answer;as answer){
     @if(answer.actions.length){<div class="support-links">@for(action of answer.actions;track action.label){
      @if(action.kind==='route'){<a [routerLink]="action.path" [fragment]="action.fragment" (click)="close(false)">{{action.label}}</a>}
      @else if(action.kind==='email'){<a [href]="portal.gmailUrl" target="_blank" rel="noopener noreferrer">{{action.label}}</a>}
      @else if(action.kind==='auth'){<button type="button" (click)="openAuth(action)">{{action.label}}</button>}
     }</div>}
     <span class="support-source">{{answer.source}}</span>
    }
   </article>}
  </div>
  @if(suggestions().length){<div class="support-suggestions" aria-label="Önerilen sorular">@for(question of suggestions();track question){<button type="button" (click)="ask(question)">{{question}}</button>}</div>}
  <form class="support-compose" (ngSubmit)="send()"><label for="support-question" class="support-sr-only">Asistana sorunu yaz</label><input #questionInput id="support-question" name="question" [(ngModel)]="question" placeholder="Bir soru yaz…" maxlength="500" autocomplete="off" enterkeyhint="send"><button type="submit" [disabled]="!question.trim()" aria-label="Mesajı gönder"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><path d="m5 12 7-7 7 7M12 5v15"/></svg></button></form>
  <p class="support-footnote">Hazır site bilgilerine göre yanıtlar. Sohbet kaydedilmez.</p>
 </section>}
 <button #launcher type="button" class="support-launcher" [class.is-open]="opened()" [attr.aria-label]="opened()?'Destek asistanını kapat':'Destek asistanını aç'" [attr.aria-expanded]="opened()" aria-controls="support-chat" aria-haspopup="dialog" (click)="toggle()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true">@if(opened()){<path d="m6 6 12 12M18 6 6 18"/>}@else{<path d="M5 4h14a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-8l-6 4v-4H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2Z"/><path d="M7 9h10M7 13h6"/>}</svg><span class="support-launcher-label">Bir sorun mu var?</span></button>
`})
export class SupportChatComponent {
 portal=inject(PortalService);opened=signal(false);messages=signal<ChatMessage[]>([]);suggestions=signal<string[]>([]);question='';private topic='';private sequence=0;
 @ViewChild('launcher',{static:true})launcher!:ElementRef<HTMLButtonElement>;
 @ViewChild('questionInput')questionInput?:ElementRef<HTMLInputElement>;
 @ViewChild('messagesElement')messagesElement?:ElementRef<HTMLDivElement>;
 constructor(){this.reset(false);}
 toggle(){if(this.opened())this.close();else{this.opened.set(true);this.focusInput();}}
 close(restoreFocus=true){this.opened.set(false);if(restoreFocus)this.launcher.nativeElement.focus({preventScroll:true});}
 reset(focus=true){this.topic='';this.question='';this.messages.set([]);this.addAnswer(answerSupport('merhaba',this.context()) as SupportAnswer);if(focus)this.focusInput();}
 private context(){return{topic:this.topic,profile:this.portal.profile(),orderTypes:this.portal.orderTypes};}
 private addAnswer(answer:SupportAnswer){this.messages.update(messages=>[...messages,{id:++this.sequence,role:'assistant',text:answer.text,answer}]);this.suggestions.set(answer.suggestions);if(answer.matched)this.topic=answer.topic;}
 send(){const question=this.question.trim().slice(0,500);if(!question)return;this.question='';this.ask(question);}
 ask(question:string){this.messages.update(messages=>[...messages.slice(-38),{id:++this.sequence,role:'user',text:question}]);this.addAnswer(answerSupport(question,this.context()) as SupportAnswer);this.focusInput();}
 openAuth(action:SupportAction){this.close(false);this.portal.openAuth(action.mode==='signup'?'signup':'login');}
 private focusInput(){requestAnimationFrame(()=>{this.questionInput?.nativeElement.focus({preventScroll:true});const log=this.messagesElement?.nativeElement;if(log)log.scrollTop=log.scrollHeight;});}
 @HostListener('keydown.escape',['$event'])escape(event:Event){if(this.opened()){event.stopPropagation();event.preventDefault();this.close();}}
}
