import {DestroyRef,Injectable,inject,signal} from '@angular/core';
import {Subject} from 'rxjs';
import {DEFAULT_OWNER,ORDER_TYPES} from './portal-config.mjs';
import type {AuthMode} from './auth-validation';

export interface PortalUser {id:string;username:string;displayName:string;email:string;phone:string;role:'admin'|'member';status:string;createdAt:string;}
export class PortalError extends Error {constructor(message:string,public status:number,public fields:any={}){super(message);}}
@Injectable({providedIn:'root'})
export class PortalService {
 user=signal<PortalUser|null>(null);profile=signal({...DEFAULT_OWNER});ready=signal(false);serviceReady=signal(false);unread=signal(0);pending=signal(0);notifications=signal<any[]>([]);authRequests=new Subject<AuthMode>();orderTypes=ORDER_TYPES;
 private destroy=inject(DestroyRef);
 constructor(){void this.initialize();let tick=0;const timer=setInterval(()=>{if(this.user())void this.refreshSession();if(++tick%3===0)void this.refreshPublicProfile();},20000);this.destroy.onDestroy(()=>clearInterval(timer));}
 get isAdmin(){return this.user()?.role==='admin';}
 get firstName(){return this.profile().displayName.split(' ')[0];}
 get familyName(){return this.profile().displayName.split(' ').slice(1).join(' ');}
 get initials(){return this.profile().displayName.split(' ').filter(Boolean).map((p:string)=>p[0]).slice(0,2).join('').toLocaleUpperCase('tr');}
 get gmailUrl(){return'https://mail.google.com/mail/?view=cm&fs=1&to='+encodeURIComponent(this.profile().email)+'&su='+encodeURIComponent('Portföy üzerinden iletişim');}
 get phoneUrl(){return'tel:'+this.profile().phone.replace(/[^+0-9]/g,'');}
 openAuth(mode:AuthMode='login'){this.authRequests.next(mode);}
 async request<T=any>(route:string,method='GET',body?:unknown):Promise<T>{
  let response:Response;try{response=await fetch('/api'+route,{method,credentials:'same-origin',headers:{'content-type':'application/json','x-portfolio-request':'1'},...(body===undefined?{}:{body:JSON.stringify(body)})});}catch{throw new PortalError('Üyelik hizmetine ulaşılamadı. Bağlantınızı kontrol edin.',503);}
  if(!response.headers.get('content-type')?.includes('application/json'))throw new PortalError('Üyelik sunucusuna ulaşılamadı. Siteyi sunucu üzerinden açın.',503);
  const data=await response.json().catch(()=>({error:'Üyelik sunucusuna ulaşılamadı. Siteyi sunucu üzerinden açın.'}));
  if(!response.ok){if(response.status===401&&!route.startsWith('/auth/'))this.clearSession();throw new PortalError(data.error||'İşlem tamamlanamadı.',response.status,data.fields);}
  return data as T;
 }
 async initialize(){try{const data:any=await this.request('/public-profile');this.profile.set(data.profile);this.serviceReady.set(data.accountServiceReady);await this.refreshSession();}catch{this.serviceReady.set(false);}finally{this.ready.set(true);}}
 async refreshPublicProfile(){try{const data:any=await this.request('/public-profile');this.profile.set(data.profile);this.serviceReady.set(data.accountServiceReady);}catch{}}
 async refreshSession(){try{const result:any=await this.request('/session');this.user.set(result.user);if(result.user?.role==='admin')await this.refreshNotifications();else{this.unread.set(0);this.pending.set(0);this.notifications.set([]);}}catch(error){if((error as PortalError).status===401)this.clearSession();}}
 async login(username:string,password:string){const data:any=await this.request('/auth/login','POST',{username,password});this.user.set(data.user);if(this.isAdmin)await this.refreshNotifications();return data;}
 async logout(){await this.request('/auth/logout','POST',{});this.clearSession();}
 clearSession(){this.user.set(null);this.unread.set(0);this.pending.set(0);this.notifications.set([]);}
 async refreshNotifications(){if(!this.isAdmin)return;try{const data:any=await this.request('/admin/notifications');this.notifications.set(data.notifications);this.unread.set(data.unread);this.pending.set(data.pending);}catch{}}
 async saveAccount(body:any){const data:any=await this.request('/account','PATCH',body);this.user.set(data.user);this.profile.set(data.profile);return data;}
 async deleteAccount(password:string,confirmation:string){const data:any=await this.request('/account/delete','POST',{password,confirmation});this.clearSession();return data;}
}
