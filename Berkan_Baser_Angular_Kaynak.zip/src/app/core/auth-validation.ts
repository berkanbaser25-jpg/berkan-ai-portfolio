/** Form checks only. A future account service must validate again on the server.
 * Required consent is a prototype interaction, not a determination of legal basis.
 */
export type AuthMode = 'login' | 'signup' | 'reset';
export type AuthField = 'username' | 'email' | 'phone' | 'password' | 'confirm' | 'privacyRead' | 'processingConsent' | 'termsAccepted';
export interface AuthFields {
 username:string; email:string; phone:string; password:string; confirm:string;
 privacyRead:boolean; processingConsent:boolean; termsAccepted?:boolean;
}

export function validPhone(value:string):boolean {
 if(!/^[+\d\s().-]+$/.test(value))return false;
 let compact=value.replace(/[\s().-]/g,'');
 if(compact.startsWith('00'))compact='+'+compact.slice(2);
 if(compact.startsWith('+'))return /^\+[1-9]\d{6,14}$/.test(compact);
 return /^(?:0)?[2-5]\d{9}$/.test(compact);
}

export function validateAuthForm(mode:AuthMode,fields:AuthFields):Partial<Record<AuthField,string>> {
 const errors:Partial<Record<AuthField,string>>={};
 if(mode!=='reset'){
  const name=fields.username.trim();
  if(!name)errors.username='Kullanıcı adı zorunludur.';
  else if(name.length<(mode==='signup'?3:1)||name.length>40)errors.username='Kullanıcı adı 3–40 karakter olmalıdır.';
  if(!fields.password.trim())errors.password='Şifre zorunludur.';
  else if(fields.password.length<(mode==='signup'?8:1)||fields.password.length>128)errors.password=mode==='signup'?'Şifre 8–128 karakter olmalıdır.':'Şifre en fazla 128 karakter olabilir.';
 }
 if(mode!=='login'){
  const email=fields.email.trim();
  if(!email)errors.email='İletişim e-postası zorunludur.';
  else if(email.length>254||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))errors.email='Geçerli bir e-posta adresi girin.';
 }
 if(mode==='signup'){
  if(!fields.phone.trim())errors.phone='Telefon numarası zorunludur.';
  else if(!validPhone(fields.phone.trim()))errors.phone='Geçerli bir telefon numarası girin. Örnek: +90 532 000 00 00.';
  if(!fields.confirm)errors.confirm='Şifrenizi tekrar girin.';
  else if(fields.confirm!==fields.password)errors.confirm='Şifreler eşleşmiyor.';
  if(fields.privacyRead!==true)errors.privacyRead='Devam etmeden önce KVKK Aydınlatma Metni’ni okuyup ilgili kutuyu işaretleyin.';
  if(fields.processingConsent!==true)errors.processingConsent='Üyelik başvurusu için belirtilen veri işleme iznini onaylayın.';
  if(fields.termsAccepted!==true)errors.termsAccepted='Üyelik ve kullanım koşullarını kabul etmelisiniz.';
 }
 return errors;
}
