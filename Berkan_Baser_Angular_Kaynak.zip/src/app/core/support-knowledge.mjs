export const SUPPORT_KNOWLEDGE = [
  {
    "id": "demos",
    "topic": "projects",
    "title": "Demoları deneme",
    "questions": [
      "demolar ücretli mi",
      "projeleri denemek ücretsiz mi",
      "demo için ödeme gerekiyor mu",
      "uygulamaları deneme fiyatı"
    ],
    "text": "Market Planlayıcı ve Kavşak Laboratuvarı çalışan uygulamaları https://berkanbaser.netlify.app/ adresindedir. Yerel proje sayfalarından canlı uygulamaya geçebilirsin. Yerel üyelik ve sipariş işlemleri bu bilgisayarda çalışır.",
    "actions": [
      {
        "label": "Market demosu",
        "kind": "route",
        "path": "/projeler/market"
      },
      {
        "label": "Kavşak demosu",
        "kind": "route",
        "path": "/projeler/kavsak"
      }
    ],
    "suggestions": [
      "Projeleri tanıt",
      "Nasıl teklif alırım?"
    ]
  },
  {
    "id": "welcome",
    "topic": "general",
    "title": "Site rehberi",
    "questions": [
      "merhaba",
      "selam",
      "iyi günler",
      "nasılsın",
      "bana yardımcı olur musun"
    ],
    "text": "Merhaba! Projeler, hizmet türleri, ön bütçeler ve üyelik konusunda yardımcı olabilirim. Ne öğrenmek istersin?",
    "suggestions": [
      "Projeleri tanıt",
      "Fiyat aralıkları",
      "Nasıl üye olurum?"
    ]
  },
  {
    "id": "services",
    "topic": "services",
    "title": "Hizmetler",
    "questions": [
      "hangi hizmetleri sunuyorsunuz",
      "ne tür yazılımlar yapıyorsunuz",
      "bana uygun yazılım hangisi",
      "bir program yaptırmak istiyorum",
      "nasıl bir proje seçmeliyim"
    ],
    "text": "Üç hizmet türü var: yapay zekâ algoritması, internet sitesi ve isteğe özel program. Tahmin veya görüntü analizi için yapay zekâ; tanıtım ve web platformu için internet sitesi; iş akışını otomatikleştirmek için özel program seçebilirsin. Talebinde amacını kısaca anlatman yeterli.",
    "actions": [
      {
        "label": "Sipariş ver",
        "kind": "route",
        "path": "/siparis-ver"
      }
    ],
    "suggestions": [
      "Yapay zekâ fiyatı",
      "Web sitesi fiyatı",
      "Özel program fiyatı"
    ]
  },
  {
    "id": "pricing",
    "topic": "pricing",
    "title": "Ön bütçe aralıkları",
    "questions": [
      "fiyat aralıkları",
      "fiyatlar ne kadar",
      "ücret hakkında bilgi",
      "bütçeler nedir",
      "yazılım maliyeti",
      "fiyat teklifi almak istiyorum"
    ],
    "text": "Ön bütçeler şöyle:\n• Yapay zekâ algoritması: {price_ai}\n• İnternet sitesi: {price_website}\n• İsteğe özel program: {price_software}\nBunlar kesin teklif değildir. Kapsam incelendikten sonra fiyat belirlenir; talep formu ödeme almaz.",
    "actions": [
      {
        "label": "Sipariş ver",
        "kind": "route",
        "path": "/siparis-ver"
      }
    ],
    "suggestions": [
      "Nasıl teklif alırım?",
      "Hangi hizmeti seçmeliyim?"
    ]
  },
  {
    "id": "price-ai",
    "topic": "ai",
    "title": "Yapay zekâ hizmeti",
    "questions": [
      "yapay zeka algoritması fiyatı",
      "yapay zeka yaptırmak ne kadar",
      "görüntü işleme projesi ücreti",
      "tahmin modeli maliyeti",
      "ai fiyatı"
    ],
    "text": "Yapay zekâ algoritmaları için ön bütçe {price_ai}. Veri hazırlığı, modelin kapsamı ve entegrasyon ihtiyaçlarına göre kesin teklif hazırlanır. Bu aralık satış garantisi veya kesin fiyat değildir.",
    "actions": [
      {
        "label": "Sipariş ver",
        "kind": "route",
        "path": "/siparis-ver"
      }
    ],
    "suggestions": [
      "Nasıl teklif alırım?",
      "Market projesi nedir?"
    ]
  },
  {
    "id": "price-website",
    "topic": "website",
    "title": "İnternet sitesi hizmeti",
    "questions": [
      "web sitesi fiyatı",
      "internet sitesi yaptırmak ne kadar",
      "web tasarım ücreti",
      "kurumsal site maliyeti",
      "tanıtım sitesi bütçesi",
      "site yaptırmak kaç para"
    ],
    "text": "İnternet sitesi için ön bütçe {price_website}. Sayfalar, tasarım ve üyelik gibi işlevler kapsamı belirler. Kesin fiyat, talebin değerlendirilmesinden sonra verilir.",
    "actions": [
      {
        "label": "Sipariş ver",
        "kind": "route",
        "path": "/siparis-ver"
      }
    ],
    "suggestions": [
      "Nasıl teklif alırım?",
      "Üyelik gerekli mi?"
    ]
  },
  {
    "id": "price-software",
    "topic": "software",
    "title": "İsteğe özel program",
    "questions": [
      "özel program fiyatı",
      "masaüstü uygulama ücreti",
      "otomasyon yaptırmak ne kadar",
      "iş takip yazılımı bütçesi",
      "uygulanabilir program maliyeti"
    ],
    "text": "İsteğe özel program için ön bütçe {price_software}. Üst sınır, ihtiyaç ve iş kapsamı incelendikten sonra belirlenir. İş akışını ve çözmek istediğin sorunu talep formunda anlatabilirsin.",
    "actions": [
      {
        "label": "Sipariş ver",
        "kind": "route",
        "path": "/siparis-ver"
      }
    ],
    "suggestions": [
      "Nasıl teklif alırım?",
      "İletişim bilgileri"
    ]
  },
  {
    "id": "quote",
    "topic": "orders",
    "title": "Teklif süreci",
    "questions": [
      "nasıl teklif alırım",
      "nasıl sipariş verebilirim",
      "talep göndermek istiyorum",
      "teklif süreci nasıl ilerliyor",
      "sipariş vermek için ne yapmalıyım"
    ],
    "text": "Önce üye ol ve yönetici onayından sonra giriş yap. Sipariş ver sayfasında yazılım türünü seçip 10–4000 karakterlik açıklamanı gönder. Talebin yöneticiye uygulama içi bildirim olarak ulaşır. Durumunu Siparişlerim bölümünden izleyebilirsin.",
    "actions": [
      {
        "label": "Sipariş ver",
        "kind": "route",
        "path": "/siparis-ver"
      }
    ],
    "suggestions": [
      "Nasıl üye olurum?",
      "Siparişimi nasıl takip ederim?"
    ]
  },
  {
    "id": "signup",
    "topic": "membership",
    "title": "Üyelik başvurusu",
    "questions": [
      "nasıl üye olurum",
      "üyelik gerekli mi",
      "kayıt olmak istiyorum",
      "üye olmadan sipariş verebilir miyim",
      "üye olma şartları",
      "kaydolmak için ne gerekli"
    ],
    "text": "Üyelik başvurusunda kullanıcı adı, e-posta, telefon ve şifre zorunlu. Aydınlatma, işleme izni ve üyelik koşulları onaylarını tamamlamalısın. Yeni hesaplar yönetici onayından sonra etkinleşir. Projeleri incelemek için üyelik gerekmez; talep göndermek için aktif üyelik gerekir.",
    "actions": [
      {
        "label": "Üye ol",
        "kind": "auth",
        "mode": "signup"
      }
    ],
    "suggestions": [
      "Onay bekliyorum",
      "Nasıl giriş yaparım?"
    ]
  },
  {
    "id": "approval",
    "topic": "membership",
    "title": "Üyelik onayı",
    "questions": [
      "onay bekliyorum",
      "hesabım ne zaman aktif olacak",
      "üyeliğim onaylanmadı",
      "kaydoldum giriş yapamıyorum",
      "üyelik pasif",
      "üyeliğim iptal edildi"
    ],
    "text": "Yeni başvuruları yönetici elle onaylar; kesin bir onay süresi belirtilmiyor. Pasif veya iptal edilmiş hesaplar giriş yapamaz. Durumunu görüşmek için {owner} ile iletişime geçebilirsin. Bu asistan hesap onayı veya üyelik durumu değişikliği yapmaz.",
    "actions": [
      {
        "label": "E-posta ile ulaş",
        "kind": "email"
      }
    ],
    "suggestions": [
      "İletişim bilgileri",
      "Nasıl giriş yaparım?"
    ]
  },
  {
    "id": "login",
    "topic": "membership",
    "title": "Giriş yapma",
    "questions": [
      "nasıl giriş yaparım",
      "hesabıma giriş yapmak istiyorum",
      "giriş ekranını aç",
      "kullanıcı adı şifre ile giriş"
    ],
    "text": "Sağ üstteki Üye ol / Giriş yap düğmesinden giriş penceresini açabilirsin. Kullanıcı adını ve şifreni gir. Hesabın yönetici onayından sonra girişe açılır.",
    "actions": [
      {
        "label": "Giriş yap",
        "kind": "auth",
        "mode": "login"
      }
    ],
    "suggestions": [
      "Şifremi unuttum",
      "Onay bekliyorum"
    ]
  },
  {
    "id": "password",
    "topic": "membership",
    "title": "Şifre ve hesap ayarları",
    "questions": [
      "şifremi unuttum",
      "şifre sıfırlama",
      "şifremi nasıl değiştiririm",
      "parolamı hatırlamıyorum",
      "telefonumu değiştirmek istiyorum",
      "e postamı nasıl güncellerim"
    ],
    "text": "Giriş yapabiliyorsan kullanıcı menüsündeki Hesap ayarları bölümünden mevcut şifrenle e-posta, telefon ve şifreni değiştirebilirsin. Otomatik şifre sıfırlama e-postası henüz bağlı değil. Mevcut şifreni hatırlamıyorsan yöneticiyle iletişime geç. Asistan şifreleri göremez veya değiştiremez.",
    "actions": [
      {
        "label": "Hesap ayarları",
        "kind": "route",
        "path": "/hesap"
      },
      {
        "label": "Yöneticiye ulaş",
        "kind": "email"
      }
    ],
    "suggestions": [
      "İletişim bilgileri"
    ]
  },
  {
    "id": "delete",
    "topic": "membership",
    "title": "Hesap silme",
    "questions": [
      "hesabımı nasıl silerim",
      "üyeliğimi silmek istiyorum",
      "hesap kapatma",
      "verilerimi silmek istiyorum"
    ],
    "text": "Hesap ayarlarında kırmızı Hesabımı sil düğmesini kullanabilirsin. İşlem mevcut şifreni ve HESABIMI SİL onayını ister. Üyeliğin ve kayıtlı talep bilgilerin kalıcı olarak silinir. Bu asistan hesabını senin yerine silmez.",
    "actions": [
      {
        "label": "Hesap ayarları",
        "kind": "route",
        "path": "/hesap"
      }
    ],
    "suggestions": [
      "İletişim bilgileri"
    ]
  },
  {
    "id": "tracking",
    "topic": "orders",
    "title": "Talep takibi",
    "questions": [
      "siparişimi nasıl takip ederim",
      "siparişim ne durumda",
      "talebimin durumu nedir",
      "sipariş numaram",
      "teklifim hazır mı",
      "talep geçmişi nerede"
    ],
    "text": "Giriş yaptıktan sonra kullanıcı menüsünden Siparişlerim sayfasını aç. Yalnızca kendi taleplerini, güncel durumlarını ve yöneticinin süreç notlarını görebilirsin. Asistan kişisel sipariş kayıtlarını okumaz.",
    "actions": [
      {
        "label": "Siparişlerim",
        "kind": "route",
        "path": "/siparislerim"
      }
    ],
    "suggestions": [
      "Nasıl teklif alırım?",
      "İletişim bilgileri"
    ]
  },
  {
    "id": "delivery",
    "topic": "orders",
    "title": "Teslim süresi",
    "questions": [
      "kaç günde teslim edersiniz",
      "teslim süresi nedir",
      "proje ne zaman biter",
      "ne kadar sürede hazır olur"
    ],
    "text": "Sitede sabit bir teslim süresi belirtilmiyor. Süre; istenen işlevler, veri hazırlığı ve proje kapsamı incelendikten sonra netleşir. Talebinde hedef tarihini paylaşabilirsin.",
    "actions": [
      {
        "label": "Sipariş ver",
        "kind": "route",
        "path": "/siparis-ver"
      }
    ],
    "suggestions": [
      "Nasıl teklif alırım?",
      "Fiyat aralıkları"
    ]
  },
  {
    "id": "payment",
    "topic": "orders",
    "title": "Ödeme ve kesin teklif",
    "questions": [
      "nasıl ödeme yaparım",
      "kredi kartı geçiyor mu",
      "taksit var mı",
      "ödeme alıyor musunuz",
      "indirim yapar mısınız"
    ],
    "text": "Mevcut talep formu ödeme almaz ve ödeme yükümlülüğü oluşturmaz. Ödeme yöntemi, taksit veya indirim için sitede doğrulanmış bilgi bulunmuyor. Kesin teklif ve koşulları {owner} ile görüşmelisin.",
    "actions": [
      {
        "label": "E-posta ile görüş",
        "kind": "email"
      }
    ],
    "suggestions": [
      "Fiyat aralıkları",
      "Nasıl teklif alırım?"
    ]
  },
  {
    "id": "projects",
    "topic": "projects",
    "title": "Portföy projeleri",
    "questions": [
      "projeleri tanıt",
      "hangi projeler var",
      "yaptığınız çalışmaları görmek istiyorum",
      "demolar neler",
      "yapay zeka projeleri"
    ],
    "text": "İki çalışan demo var: Market Planlayıcı günlük ciro ve kampanya tarihlerini karşılaştırır. Sentetik Kavşak Laboratuvarı ise kurgusal araç görüntülerinde özellik eşleştirme, netleştirme ve plaka okumayı gösterir. İkisini de üyelik olmadan deneyebilirsin.",
    "actions": [
      {
        "label": "Market Planlayıcı",
        "kind": "route",
        "path": "/projeler/market"
      },
      {
        "label": "Kavşak Laboratuvarı",
        "kind": "route",
        "path": "/projeler/kavsak"
      }
    ],
    "suggestions": [
      "Market projesi nedir?",
      "Kavşak projesi nedir?"
    ]
  },
  {
    "id": "market",
    "topic": "market",
    "title": "Market Planlayıcı",
    "questions": [
      "market projesi nedir",
      "market regresyonu nasıl çalışıyor",
      "ciro tahmini nasıl yapılıyor",
      "kampanya hangi gün yapılmalı",
      "market modeli hangi algoritma",
      "ridge regresyonu"
    ],
    "text": "Market Planlayıcı çalışan uygulaması https://berkanbaser.netlify.app/projeler/market adresinde kullanılabilir. Bu kaynak sürümünde bu uygulamanın algoritma kodları, modelleri ve verileri dağıtılmaz. Yerel proje sayfasındaki bağlantıdan canlı sürüme geçebilirsin.",
    "actions": [
      {
        "label": "Market Planlayıcı bağlantısı",
        "kind": "route",
        "path": "/projeler/market"
      }
    ],
    "suggestions": [
      "Market nasıl kullanılır?",
      "Market verileri gerçek mi?",
      "Market raporu"
    ]
  },
  {
    "id": "market-guide",
    "topic": "market",
    "title": "Market kullanım kılavuzu",
    "questions": [
      "market nasıl kullanılır",
      "kampanya planı nasıl oluşturulur",
      "market demosunu denemek istiyorum"
    ],
    "text": "Market Planlayıcı çalışan uygulaması https://berkanbaser.netlify.app/projeler/market adresinde kullanılabilir. Bu kaynak sürümünde bu uygulamanın algoritma kodları, modelleri ve verileri dağıtılmaz. Yerel proje sayfasındaki bağlantıdan canlı sürüme geçebilirsin.",
    "actions": [
      {
        "label": "Market Planlayıcı bağlantısı",
        "kind": "route",
        "path": "/projeler/market"
      }
    ],
    "suggestions": [
      "Market verileri gerçek mi?",
      "Market raporu"
    ]
  },
  {
    "id": "market-data",
    "topic": "market",
    "title": "Market verileri ve sınırlar",
    "questions": [
      "market verileri gerçek mi",
      "market veri seti hangi yıllar",
      "market doğruluk oranı",
      "market mape kaç",
      "walmart verisi kullanıldı mı"
    ],
    "text": "Market Planlayıcı çalışan uygulaması https://berkanbaser.netlify.app/projeler/market adresinde kullanılabilir. Bu kaynak sürümünde bu uygulamanın algoritma kodları, modelleri ve verileri dağıtılmaz. Yerel proje sayfasındaki bağlantıdan canlı sürüme geçebilirsin.",
    "actions": [
      {
        "label": "Market Planlayıcı bağlantısı",
        "kind": "route",
        "path": "/projeler/market"
      }
    ],
    "suggestions": [
      "Market raporu"
    ]
  },
  {
    "id": "junction",
    "topic": "junction",
    "title": "Sentetik Kavşak Laboratuvarı",
    "questions": [
      "kavşak projesi nedir",
      "araç takip uygulaması nasıl çalışıyor",
      "mobese uygulaması",
      "plaka okuma modeli",
      "kamera projesi hangi algoritma"
    ],
    "text": "Kavşak Laboratuvarı çalışan uygulaması https://berkanbaser.netlify.app/projeler/kavsak adresinde kullanılabilir. Bu kaynak sürümünde bu uygulamanın algoritma kodları, modelleri ve verileri dağıtılmaz. Yerel proje sayfasındaki bağlantıdan canlı sürüme geçebilirsin.",
    "actions": [
      {
        "label": "Kavşak Laboratuvarı bağlantısı",
        "kind": "route",
        "path": "/projeler/kavsak"
      }
    ],
    "suggestions": [
      "Kavşak nasıl kullanılır?",
      "Kavşak verileri gerçek mi?",
      "Kavşak raporu"
    ]
  },
  {
    "id": "junction-guide",
    "topic": "junction",
    "title": "Kavşak kullanım kılavuzu",
    "questions": [
      "kavşak nasıl kullanılır",
      "araç araması nasıl yapılır",
      "plakası eksik araç nasıl aranır",
      "kamera demosunu denemek istiyorum"
    ],
    "text": "Kavşak Laboratuvarı çalışan uygulaması https://berkanbaser.netlify.app/projeler/kavsak adresinde kullanılabilir. Bu kaynak sürümünde bu uygulamanın algoritma kodları, modelleri ve verileri dağıtılmaz. Yerel proje sayfasındaki bağlantıdan canlı sürüme geçebilirsin.",
    "actions": [
      {
        "label": "Kavşak Laboratuvarı bağlantısı",
        "kind": "route",
        "path": "/projeler/kavsak"
      }
    ],
    "suggestions": [
      "Kavşak verileri gerçek mi?",
      "Kavşak raporu"
    ]
  },
  {
    "id": "junction-data",
    "topic": "junction",
    "title": "Kavşak verileri ve sınırlar",
    "questions": [
      "kavşak verileri gerçek mi",
      "kaç araç var",
      "kameralar bağlı mı",
      "gerçek plaka kullanılıyor mu",
      "kavşak model doğruluğu"
    ],
    "text": "Kavşak Laboratuvarı çalışan uygulaması https://berkanbaser.netlify.app/projeler/kavsak adresinde kullanılabilir. Bu kaynak sürümünde bu uygulamanın algoritma kodları, modelleri ve verileri dağıtılmaz. Yerel proje sayfasındaki bağlantıdan canlı sürüme geçebilirsin.",
    "actions": [
      {
        "label": "Kavşak Laboratuvarı bağlantısı",
        "kind": "route",
        "path": "/projeler/kavsak"
      }
    ],
    "suggestions": [
      "Kavşak raporu"
    ]
  },
  {
    "id": "market-docs",
    "topic": "market",
    "title": "Market teslim dosyaları",
    "questions": [
      "market raporu",
      "market ipynb dosyası",
      "market proje özeti indir",
      "market dokümantasyonu"
    ],
    "text": "Market Planlayıcı çalışan uygulaması https://berkanbaser.netlify.app/projeler/market adresinde kullanılabilir. Bu kaynak sürümünde bu uygulamanın algoritma kodları, modelleri ve verileri dağıtılmaz. Yerel proje sayfasındaki bağlantıdan canlı sürüme geçebilirsin.",
    "actions": [
      {
        "label": "Market Planlayıcı bağlantısı",
        "kind": "route",
        "path": "/projeler/market"
      }
    ]
  },
  {
    "id": "junction-docs",
    "topic": "junction",
    "title": "Kavşak teslim dosyaları",
    "questions": [
      "kavşak raporu",
      "kavşak ipynb dosyası",
      "araç takip proje özeti indir",
      "kavşak dokümantasyonu"
    ],
    "text": "Kavşak Laboratuvarı çalışan uygulaması https://berkanbaser.netlify.app/projeler/kavsak adresinde kullanılabilir. Bu kaynak sürümünde bu uygulamanın algoritma kodları, modelleri ve verileri dağıtılmaz. Yerel proje sayfasındaki bağlantıdan canlı sürüme geçebilirsin.",
    "actions": [
      {
        "label": "Kavşak Laboratuvarı bağlantısı",
        "kind": "route",
        "path": "/projeler/kavsak"
      }
    ]
  },
  {
    "id": "contact",
    "topic": "contact",
    "title": "İletişim",
    "questions": [
      "iletişim bilgileri",
      "size nasıl ulaşırım",
      "e posta adresiniz nedir",
      "telefon numaranız",
      "berkan ile görüşmek istiyorum",
      "bir insanla görüşmek istiyorum"
    ],
    "text": "{owner} ile {email} adresinden veya {phone} numarasından iletişime geçebilirsin. E-posta düğmesi, alıcı adresi doldurulmuş bir Gmail taslağı açar; mesajı sen gönderirsin.",
    "actions": [
      {
        "label": "E-posta gönder",
        "kind": "email"
      },
      {
        "label": "İletişim sayfası",
        "kind": "route",
        "path": "/hakkimda",
        "fragment": "iletisim"
      }
    ],
    "suggestions": [
      "Nasıl teklif alırım?"
    ]
  },
  {
    "id": "about",
    "topic": "about",
    "title": "Geliştirici hakkında",
    "questions": [
      "berkan kimdir",
      "sitenin sahibi kim",
      "kendini tanıt",
      "hakkınızda bilgi",
      "hangi teknolojileri kullanıyorsunuz"
    ],
    "text": "Bu portföy {owner} tarafından yapay zekâ ve web geliştirme çalışmalarını tanıtmak için hazırlandı. Python, derin öğrenme, Angular ve veri görselleştirme çalışmaları; market ve sentetik kavşak demolarıyla bir araya geliyor.",
    "actions": [
      {
        "label": "Hakkımda",
        "kind": "route",
        "path": "/hakkimda"
      }
    ],
    "suggestions": [
      "Projeleri tanıt",
      "İletişim bilgileri"
    ]
  },
  {
    "id": "privacy",
    "topic": "privacy",
    "title": "Asistanın kapsamı",
    "questions": [
      "mesajlarımı kaydediyor musun",
      "sohbet gizliliği",
      "bu chatbot nasıl çalışıyor",
      "sen yapay zeka mısın",
      "beni canlı birine bağla",
      "kvkk bilgileri"
    ],
    "text": "Bu asistan hazır site bilgileri içinde soru eşleştirir; büyük bir dil modeli kullanmaz. Sohbet geçmişi yalnızca açık sayfanın belleğinde kalır; sunucuya gönderilmez ve sayfa yenilenince silinir. Kişisel üyelik veya sipariş kayıtlarını okumaz. Canlı temsilci bağlantısı yoktur; iletişim sayfasından {owner} ile görüşebilirsin.",
    "actions": [
      {
        "label": "İletişim sayfası",
        "kind": "route",
        "path": "/hakkimda",
        "fragment": "iletisim"
      }
    ],
    "suggestions": [
      "İletişim bilgileri"
    ]
  }
];
