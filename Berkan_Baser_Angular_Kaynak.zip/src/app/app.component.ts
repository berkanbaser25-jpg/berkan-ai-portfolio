import { Component, HostListener, effect, inject, signal } from '@angular/core';
import { NavigationEnd, Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthDialogComponent } from './core/auth-dialog.component';
import {PortalService} from './core/portal.service';
import {SupportChatComponent} from './core/support-chat.component';

@Component({ selector: 'app-root', standalone: true, imports: [RouterLink,RouterLinkActive,RouterOutlet,AuthDialogComponent,SupportChatComponent], template: `
<a class="skip-link" href="#main" (click)="skipToContent($event)">İçeriğe geç</a>
<header class="site-header"><div class="container nav-wrap">
  <a routerLink="/" class="brand" [attr.aria-label]="portal.profile().displayName+' ana sayfa'" (click)="menu.set(false)"><span class="brand-symbol">{{portal.firstName[0]?.toLocaleLowerCase('tr')}}<span>.</span></span><span>{{portal.firstName}}<span class="brand-last">{{portal.familyName}}</span></span></a>
  <nav id="site-navigation" [class.open]="menu()" aria-label="Ana menü">
    <a routerLink="/" routerLinkActive="active" [routerLinkActiveOptions]="{exact:true}" (click)="menu.set(false)">Ana sayfa</a>
    <a routerLink="/projeler/market" routerLinkActive="active" (click)="menu.set(false)">Market Planlayıcı</a>
    <a routerLink="/projeler/kavsak" routerLinkActive="active" (click)="menu.set(false)">Kavşak Laboratuvarı</a>
    <a routerLink="/siparis-ver" routerLinkActive="active" (click)="menu.set(false)">Sipariş ver</a>
    <a routerLink="/hakkimda" routerLinkActive="active" (click)="menu.set(false)">Hakkımda</a>
    <a routerLink="/hakkimda" fragment="iletisim" class="nav-contact" (click)="menu.set(false)">İletişim</a>
  </nav>
  <div class="header-actions">
   <button class="menu-toggle" type="button" (click)="menu.set(!menu())" [attr.aria-expanded]="menu()" [attr.aria-label]="menu()?'Menüyü kapat':'Menü'" aria-controls="site-navigation"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><path [attr.d]="menu()?'m6 6 12 12M18 6 6 18':'M4 6h16M4 12h16M4 18h16'"/></svg><span class="menu-text">{{menu()?'Kapat':'Menü'}}</span></button>
   @if(portal.user();as user){<div class="account-widget">
    <button class="avatar-button" type="button" [attr.aria-label]="'Kullanıcı menüsü: '+user.username" [attr.aria-expanded]="accountMenu()" aria-controls="account-menu" (click)="accountMenu.set(!accountMenu());menu.set(false)"><svg width="23" height="23" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><circle cx="12" cy="8" r="3.5"/><path d="M5 21v-2a7 7 0 0 1 14 0v2"/></svg>@if(portal.isAdmin&&portal.unread()){<span class="notification-dot">{{portal.unread()>9?'9+':portal.unread()}}</span>}</button>
    @if(accountMenu()){<div id="account-menu" class="account-popover" role="navigation" aria-label="Kullanıcı işlemleri"><div class="account-popover-title"><b>{{user.displayName}}</b><span>{{portal.isAdmin?'Yönetici':'Üye'}}</span></div><a routerLink="/hesap" (click)="accountMenu.set(false)">{{portal.isAdmin?'Hesabı yönet':'Hesap ayarları'}}</a>
     @if(portal.isAdmin){<a routerLink="/yonetim" [queryParams]="{sekme:'uyeler'}" (click)="accountMenu.set(false)">Üyeleri yönet @if(portal.pending()){<span>{{portal.pending()}}</span>}</a><a routerLink="/yonetim" [queryParams]="{sekme:'siparisler'}" (click)="accountMenu.set(false)">Sipariş talepleri</a><a routerLink="/yonetim" [queryParams]="{sekme:'bildirimler'}" (click)="accountMenu.set(false)">Bildirimler @if(portal.unread()){<span>{{portal.unread()}}</span>}</a>}
     @else{<a routerLink="/siparislerim" (click)="accountMenu.set(false)">Siparişlerim</a>}
     <button type="button" class="account-logout" (click)="signOut()">Çıkış yap</button></div>}
   </div>}@else{<button class="header-auth" type="button" aria-haspopup="dialog" (click)="menu.set(false);auth.open()">Üye ol / Giriş yap</button>}
  </div>
</div></header>
<main id="main" tabindex="-1"><router-outlet/></main>
@if(notice()){<div class="portal-toast" role="alert">{{notice()}}<button type="button" (click)="notice.set('')" aria-label="Uyarıyı kapat">×</button></div>}
<footer class="site-footer"><div class="container footer-grid"><a routerLink="/" class="footer-name">{{portal.profile().displayName}}<span>Yapay zekâ & web geliştirme</span></a><p>Fikirden modele, modelden kullanılabilir bir deneyime.</p><a [href]="portal.gmailUrl" target="_blank" rel="noopener noreferrer" title="Gmail ile yeni e-posta taslağı aç">{{portal.profile().email}}</a></div><div class="container footer-bottom"><span>© {{year}} {{portal.profile().displayName}}</span><span>Angular ile geliştirildi. Yapay zekâ uygulamaları canlı sitededir.</span></div></footer>
<app-auth-dialog #auth/>
<app-support-chat/>
` })
export class AppComponent {
 portal=inject(PortalService);router=inject(Router);accountMenu=signal(false);notice=signal('');menu=signal(false);year=new Date().getFullYear();
 constructor(){effect(()=>{const name=this.portal.profile().displayName;queueMicrotask(()=>this.setTitle(name));});this.router.events.subscribe(event=>{if(event instanceof NavigationEnd){this.accountMenu.set(false);queueMicrotask(()=>this.setTitle(this.portal.profile().displayName));}});}
 private setTitle(name:string){const route=this.router.url.split('?')[0].split('#')[0],titles:Record<string,string>={'/':'Yapay zekâ ve web geliştirme','/projeler/market':'Market Planlayıcı','/projeler/kavsak':'Kavşak Laboratuvarı','/hakkimda':'Hakkımda ve iletişim','/siparis-ver':'Sipariş ver','/siparislerim':'Siparişlerim','/hesap':'Hesap ayarları','/yonetim':'Yönetim'};document.title=(titles[route]||'Portföy')+' | '+name;}
 @HostListener('document:keydown.escape')closeAccount(){this.accountMenu.set(false);}
 @HostListener('document:click',['$event'])outsideAccount(event:MouseEvent){if(!(event.target instanceof Element)||!event.target.closest('.account-widget'))this.accountMenu.set(false);}
 async signOut(){try{await this.portal.logout();this.accountMenu.set(false);await this.router.navigateByUrl('/');}catch(error){this.notice.set((error as Error).message);}}
 skipToContent(event:Event){event.preventDefault();const main=document.getElementById('main');main?.focus();main?.scrollIntoView({behavior:'smooth'});}
}
