import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
@Component({standalone:true,imports:[RouterLink],template:`
<section class="container section project-intro">
 <a routerLink="/" class="breadcrumb">Projeler / Kavşak Laboratuvarı</a>
 <div class="section-heading"><div><p class="eyebrow">CANLI UYGULAMA</p>
 <h1>Kavşak Laboratuvarı</h1><p class="intro-text">Sentetik kavşak ve plaka görüntüsü uygulamasını canlı sitede kullanabilirsin.</p></div></div>
 <div class="panel"><h2>Uygulamayı Netlify üzerinde aç</h2>
 <p>Bu yerel sürüm portföy, üyelik ve sipariş özelliklerini içerir. Çalışan yapay zekâ uygulaması aşağıdaki bağlantıda bulunur.</p>
 <div class="button-row"><a class="button primary" href="https://berkanbaser.netlify.app/projeler/kavsak" target="_blank" rel="noopener noreferrer">Kavşak Laboratuvarı uygulamasını aç</a>
 <a class="button secondary" routerLink="/">Ana sayfaya dön</a></div>
 <p class="caption">Bağlantı yeni sekmede açılır. Yerel oturumun bu sayfada korunur. Canlı uygulama için internet bağlantısı gerekir.</p>
 </div>
</section>`})
export class JunctionComponent {}
