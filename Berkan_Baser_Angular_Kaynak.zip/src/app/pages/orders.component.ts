import {Component,effect,inject,signal} from '@angular/core';
import {RouterLink} from '@angular/router';
import {PortalService} from '../core/portal.service';
import {ORDER_STATUSES} from '../core/portal-config.mjs';

@Component({standalone:true,imports:[RouterLink],template:`
<section class="container portal-page"><div class="portal-page-heading"><p class="eyebrow">HESABIM</p><div class="heading-with-action"><h1>Siparişlerim.</h1>@if(portal.user()){<a routerLink="/siparis-ver" class="button primary">Yeni talep</a>}</div><p>Gönderdiğiniz talepler ve süreçteki son durum.</p></div>
@if(!portal.user()){<div class="panel"><h2>Önce giriş yapmalısınız.</h2><p>Sipariş geçmişi yalnızca hesabınıza özeldir.</p><button type="button" class="button primary" (click)="portal.openAuth()">Giriş yap</button></div>}
@else{<div class="portal-toolbar"><span>{{orders().length}} sipariş talebi</span><button class="small-button" type="button" (click)="load()" [disabled]="busy()">Yenile</button></div>@if(error()){<div class="portal-feedback error" role="alert">{{error()}}</div>}@if(busy()&&!orders().length){<div class="panel" role="status">Talepler yükleniyor…</div>}@else if(!orders().length){<div class="panel empty-panel"><h2>Henüz bir talebiniz yok.</h2><p>İlk projenizi birlikte planlayabiliriz.</p><a class="button secondary" routerLink="/siparis-ver">Sipariş ver</a></div>}
@for(order of orders();track order.id){<details class="panel order-record" [open]="$first"><summary><div><b>{{order.number}}</b><span>{{order.typeLabel}} · {{date(order.createdAt)}}</span></div><span class="status-chip" [class.status-completed]="order.status==='completed'">{{status(order.status)}}</span></summary><div class="order-record-body"><p class="request-text">{{order.description}}</p><p class="caption">Başvuru anındaki ön bütçe: {{order.estimate}}. Kesin teklif değildir.</p><h3>Süreç geçmişi</h3><ol class="order-timeline">@for(item of order.history;track $index){<li><b>{{status(item.status)}}</b><time>{{date(item.at)}}</time>@if(item.note){<p>{{item.note}}</p>}</li>}</ol></div></details>}}
</section>`})
export class OrdersComponent {
 portal=inject(PortalService);orders=signal<any[]>([]);busy=signal(false);error=signal('');
 constructor(){effect(()=>{if(this.portal.user())void this.load();else this.orders.set([]);});}
 async load(){this.busy.set(true);this.error.set('');try{const data:any=await this.portal.request('/orders');this.orders.set(data.orders);}catch(error){this.error.set((error as Error).message);}finally{this.busy.set(false);}}
 status(key:string){return (ORDER_STATUSES as Record<string,string>)[key]||key;}
 date(value:string){return new Intl.DateTimeFormat('tr-TR',{dateStyle:'medium',timeStyle:'short',timeZone:'Europe/Istanbul'}).format(new Date(value));}
}
