import { Component, ElementRef, HostListener, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { PortalService } from '../core/portal.service';

@Component({standalone:true,imports:[RouterLink],styleUrl:'./presentation.component.css',template:`
<section class="presentation" [class.motion-off]="!motion()" [class.expanded]="expanded()" aria-label="Üç boyutlu portföy sunumu">
 <div class="presentation-top"><span class="edition"><i></i>PORTFÖY / İNTERAKTİF SUNUM</span>
  <div class="view-tools"><button type="button" (click)="toggleMotion()" [attr.aria-pressed]="!motion()">{{motion()?'Hareketi azalt':'Hareketi aç'}}</button><button type="button" (click)="fullscreen()">{{expanded()?'Sunumdan çık':'Tam ekran'}}</button></div>
 </div>
 <nav class="scene-nav" aria-label="Sunum bölümleri">@for(item of scenes;track item.label;let i=$index){<button type="button" (click)="go(i)" [class.current]="active()===i" [class.animate__animated]="active()===i" [class.animate__pulse]="active()===i" [attr.aria-current]="active()===i?'step':null"><span class="scene-nav-dot"></span>{{item.label}}</button>}</nav>
 @for(index of [active()];track index){
 <div class="presentation-grid">
  <div class="mobile-visual animate__animated animate__zoomIn" [class.mobile-blue]="index===2" aria-hidden="true">
   <div class="mobile-visual-caption"><span>{{scenes[index].label}}</span><span>{{index===0?'Fikirden deneyime':index===1?'Temsili senaryo':index===2?'Sentetik kamera ağı':index===3?'Geliştirme süreci':'Birlikte geliştirelim'}}</span></div>
   @switch(index){
    @case(0){<div class="mobile-brand-scene"><b>b<span>.</span></b><div class="mobile-layers"><span>VERİ</span><span>MODEL</span><span>DENEYİM</span></div></div>}
    @case(1){<div class="mobile-chart">@for(height of bars;track $index){<i [style.--bar-index]="$index" [style.height]="(height*.44)+'px'" [class.mobile-highlight]="$index===5"></i>}</div>}
    @case(2){<div class="mobile-network">@for(junction of ['K1','K2','K3'];track junction){<span>{{junction}}<i></i></span>}</div>}
    @case(3){<div class="mobile-process"><span>Problem</span><span>Model</span><span>Deneyim</span></div>}
    @case(4){<div class="mobile-contact"><b>{{portal.profile().displayName}}</b><span>{{portal.profile().email}}</span><small>{{portal.profile().phone}}</small></div>}
   }
  </div>
  <div class="scene-copy animate__animated animate__fadeInUp">
   <p class="scene-kicker">{{scenes[index].eyebrow}}</p>
   <h1 aria-live="polite">{{scenes[index].title}}<br><span>{{scenes[index].accent}}</span></h1>
   <p class="scene-description">{{scenes[index].description}}</p>
   <div class="scene-tags">@for(tag of scenes[index].tags;track tag){<span>{{tag}}</span>}</div>
   <div class="scene-actions">
    @switch(index){
     @case(0){<button class="presentation-primary" type="button" (click)="next()">Çalışmaları keşfet</button><a class="presentation-secondary" routerLink="/hakkimda">Beni tanı</a>}
     @case(1){<a class="presentation-primary" routerLink="/projeler/market">Market uygulamasını aç</a>}
     @case(2){<a class="presentation-primary" routerLink="/projeler/kavsak">Kavşak uygulamasını aç</a>}
     @case(3){<a class="presentation-primary" routerLink="/siparis-ver">Fikrini paylaş</a><a class="presentation-secondary" routerLink="/hakkimda">Yaklaşımımı incele</a>}
     @case(4){<a class="presentation-primary" [href]="portal.gmailUrl" target="_blank" rel="noopener noreferrer">E-posta ile iletişime geç</a><a class="presentation-secondary" routerLink="/siparis-ver">Proje talebi oluştur</a>}
    }
   </div>
   <div class="scene-footnote"><span></span>{{scenes[index].note}}</div>
  </div>
  <div class="scene-frame" (pointermove)="tilt($event)" (pointerleave)="resetTilt()" [class.blue-scene]="index===2" aria-label="Dekoratif üç boyutlu proje sahnesi">
   <div class="stage-grid"></div><div class="stage-glow"></div>
   <div class="visual-enter animate__animated animate__zoomIn">
   <div class="world" [style.--rx]="rx()+'deg'" [style.--ry]="ry()+'deg'" aria-hidden="true">
   @switch(index){
    @case(0){
     <div class="orbit orbit-one"></div><div class="orbit orbit-two"></div>
     <div class="brand-cube floating"><div class="cube-face front"><b>b<span>.</span></b><small>FİKİRDEN ÜRÜNE</small></div><div class="cube-face back"></div><div class="cube-face right"><span>AI</span></div><div class="cube-face left"></div><div class="cube-face top"></div><div class="cube-face bottom"></div></div>
     <div class="floating-note intro-note-one"><span>PERAKENDE ANALİTİĞİ</span><b>Doğru gün.<br>Daha iyi kampanya.</b><svg viewBox="0 0 160 46"><path d="M0 40L23 31 44 35 67 15 88 24 115 7 137 17 160 0" fill="none" stroke="#c8ed8e" stroke-width="3"/></svg></div>
     <div class="floating-note intro-note-two"><span>GÖRÜNTÜ İŞLEME</span><div class="mini-nodes"><i>K1</i><em></em><i>K2</i><em></em><i>K3</i></div><b>Veriden bağlantıya.</b></div>
    }
    @case(1){
     <div class="chart-platform"><div class="platform-grid"></div><div class="bar-row">@for(height of bars;track $index){<div class="bar" [style.--height]="height+'px'" [class.highlight]="$index===5"><i class="bar-front"></i><i class="bar-side"></i><i class="bar-top"></i></div>}</div><div class="chart-baseline"></div></div>
     <div class="floating-note market-label"><span>KAMPANYA PLANLAMA</span><b>Takvim + hava<br>+ alışveriş ilgisi.</b><div class="tiny-tags"><em>Senaryo</em><em>Karşılaştırma</em></div></div>
     <div class="calendar-object"><span>DOĞRU ZAMAN</span><div class="calendar-squares">@for(n of calendar;track n){<i [class.selected-day]="n===12||n===13||n===14"></i>}</div><small>Birlikte değerlendir.</small></div>
    }
    @case(2){
     <div class="network-board"><div class="road spine"></div>@for(j of junctions;track j.label){<div class="intersection" [style.top]="j.y+'px'"><div class="road cross-road"></div><div class="junction-center">{{j.label}}</div><span class="camera cam-one"></span><span class="camera cam-two"></span><span class="camera cam-three"></span><span class="camera cam-four"></span></div>}<div class="moving-car car-one"></div><div class="moving-car car-two"></div></div>
     <div class="floating-note network-label"><span>SENTETİK KAMERA AĞI</span><b>Aynı araç.<br>Farklı bakışlar.</b><div class="tiny-tags"><em>3 kavşak</em><em>12 kamera</em></div></div>
     <div class="plate-object"><span>GÖRÜNTÜ · NETLEŞTİRME · OCR</span><div>SIM-0<span>?</span>4</div><small>Kurgusal plaka örneği</small></div>
    }
    @case(3){
     <div class="stack-object"><div class="stack-sheet sheet-back"><span>01 / PROBLEM</span><b>Doğru soruyla başla.</b><div class="sheet-lines"><i></i><i></i><i></i></div></div><div class="stack-sheet sheet-middle"><span>02 / MODEL</span><b>Veriyle dene.</b><div class="sheet-bars"><i></i><i></i><i></i><i></i><i></i></div></div><div class="stack-sheet sheet-front"><span>03 / DENEYİM</span><b>Çalışan bir ürüne dönüştür.</b><div class="product-button">İnsanlar için geliştir.</div></div></div>
    }
    @case(4){
     <div class="contact-object floating"><div class="contact-object-top"><span>b.</span><i>YAPAY ZEKÂ & WEB GELİŞTİRME</i></div><b>{{portal.profile().displayName}}</b><p>Bir fikrin varsa,<br>birlikte geliştirebiliriz.</p><div class="contact-object-line"></div><span class="contact-email">{{portal.profile().email}}</span><small>{{portal.profile().phone}}</small></div><div class="orbit contact-orbit"></div><div class="contact-seal">FİKİR<br>+<br>TEKNOLOJİ</div>
    }
   }
   </div></div>
   <div class="stage-caption"><span>{{scenes[index].visual}}</span><span>Fareyle keşfet</span></div>
  </div>
 </div>}
 <div class="presentation-bottom" aria-label="Sunum gezinme kontrolleri"><div class="progress-info"><span>{{(active()+1).toString().padStart(2,'0')}} <i>/ {{scenes.length.toString().padStart(2,'0')}}</i></span><span class="mobile-scene-name">{{scenes[active()].label}}</span><div class="progress-track"><div [style.width]="((active()+1)/scenes.length*100)+'%'"></div></div></div><p>Yön tuşlarıyla sahneler arasında geç.</p><div class="step-controls"><button type="button" (click)="previous()" [disabled]="active()===0">Önceki</button><button type="button" (click)="next()" [disabled]="active()===scenes.length-1">Sonraki</button></div></div>
 <p class="presentation-status" role="status">{{message()}}</p>
</section>
`})
export class PresentationComponent {
 portal=inject(PortalService);host=inject(ElementRef<HTMLElement>);
 active=signal(0);rx=signal(0);ry=signal(0);message=signal('');expanded=signal(false);
 motion=signal(!matchMedia('(prefers-reduced-motion: reduce)').matches);
 bars=[78,116,95,158,132,207,171];calendar=Array.from({length:21},(_,i)=>i);junctions=[{label:'K3',y:54},{label:'K2',y:211},{label:'K1',y:368}];
 scenes=[
  {label:'Giriş',eyebrow:'BERKAN BAŞER / GELİŞTİRİCİ PORTFÖYÜ',title:'Fikirlerine',accent:'yeni bir boyut.',description:'Veriyi anlayan modeller. İnsanlar için tasarlanan deneyimler. Yapay zekâ ve web geliştirme çalışmalarımı farklı bir açıdan keşfet.',tags:['Yapay zekâ','Veri bilimi','Web geliştirme'],note:'Bir fikir, iki proje, kullanılabilir deneyimler.',visual:'Fikirden modele, modelden deneyime.'},
  {label:'Market',eyebrow:'REGRESYON / PERAKENDE ANALİTİĞİ',title:'Kampanyanın',accent:'zamanını keşfet.',description:'Hava koşullarını, takvimi ve alışveriş ilgisini birlikte değerlendir. Market Planlayıcı ile kampanya senaryolarını karşılaştır.',tags:['Ridge regresyonu','Kampanya planlama','Ciro tahmini'],note:'Çalışan demo, ayrı proje sayfasından canlı sitede açılır.',visual:'Temsili kampanya ve satış görselleştirmesi.'},
  {label:'Kavşak',eyebrow:'DERİN ÖĞRENME / GÖRÜNTÜ İŞLEME',title:'Görüntüden',accent:'bağlantıya.',description:'Birbirine bağlı üç sentetik kavşak. Farklı kamera bakışları, belirsiz araç bilgileri ve görüntü okuma adımları aynı deneyimde.',tags:['Transfer öğrenme','Süper çözünürlük','CNN OCR'],note:'Tamamen kurgusal görüntüler ve kamera ağı.',visual:'Bağlı kavşakların temsili üç boyutlu görünümü.'},
  {label:'Yaklaşım',eyebrow:'PROBLEM / MODEL / DENEYİM',title:'Bir modelden',accent:'daha fazlası.',description:'Önce hangi sorunu çözdüğümüzü anla. Verilerle dene, sonuçları değerlendir ve kullanılabilir bir web deneyimine dönüştür.',tags:['Araştır','Geliştir','Deneyerek iyileştir'],note:'Portföy, üyelik ve proje talepleri tek bir deneyimde.',visual:'Bir fikrin ürüne dönüşmesinin katmanları.'},
  {label:'İletişim',eyebrow:'BİRLİKTE GELİŞTİRELİM',title:'Konuşmaya değer',accent:'bir fikrin mi var?',description:'Yapay zekâ, web geliştirme veya sana özel bir program. İhtiyacını paylaş; ilk adımı birlikte belirleyelim.',tags:['Yapay zekâ projeleri','Web deneyimleri','Özel yazılım'],note:'E-posta bağlantısı, alıcı adresiyle Gmail taslağını açar.',visual:'Merakla başla. Çalışan bir şeye dönüştür.'}
 ];
 go(index:number){
  if(index<0||index>=this.scenes.length||index===this.active())return;
  this.active.set(index);this.resetTilt();
  if(innerWidth<=950)requestAnimationFrame(()=>requestAnimationFrame(()=>{
   const root=this.host.nativeElement as HTMLElement;
   const nav=root.querySelector<HTMLElement>('.scene-nav');
   const copy=root.querySelector<HTMLElement>(innerHeight>=600?'.presentation-grid':'.scene-copy');
   if(copy){const header=document.querySelector('.site-header')?.getBoundingClientRect().height||72;window.scrollTo({top:Math.max(0,scrollY+copy.getBoundingClientRect().top-header-16),behavior:'instant'});}
   if(nav){const button=nav.querySelectorAll('button')[index];if(button)nav.scrollLeft=Math.max(0,button.offsetLeft-nav.offsetLeft-(nav.clientWidth-button.offsetWidth)/2);}
  }));
 }
 previous(){this.go(this.active()-1);}next(){this.go(this.active()+1);}
 tilt(event:PointerEvent){if(!this.motion()||event.pointerType==='touch'||matchMedia('(prefers-reduced-motion: reduce)').matches)return;const rect=(event.currentTarget as HTMLElement).getBoundingClientRect();this.rx.set(((event.clientY-rect.top)/rect.height-.5)*-10);this.ry.set(((event.clientX-rect.left)/rect.width-.5)*14);}
 resetTilt(){this.rx.set(0);this.ry.set(0);}toggleMotion(){this.motion.update(value=>!value);this.resetTilt();}
 async fullscreen(){
  if(this.expanded()){this.expanded.set(false);if(document.fullscreenElement)await document.exitFullscreen();this.message.set('');return;}
  this.expanded.set(true);this.message.set('');
  try{await this.host.nativeElement.requestFullscreen();}catch{this.message.set('Sunum görünümü açık. Esc ile normal görünüme dönebilirsin.');}
 }
 @HostListener('document:fullscreenchange')fullscreenChanged(){if(!document.fullscreenElement)this.expanded.set(false);}
 @HostListener('window:keydown',['$event'])key(event:KeyboardEvent){if(event.key==='Escape'&&this.expanded()){this.expanded.set(false);this.message.set('');return;}if(event.altKey||event.ctrlKey||event.metaKey||(event.target as HTMLElement)?.closest('input,textarea,select,[contenteditable="true"],[role="dialog"],[role="alertdialog"]'))return;if(event.key==='ArrowRight'){event.preventDefault();this.next();}else if(event.key==='ArrowLeft'){event.preventDefault();this.previous();}else if(event.key==='Home'){event.preventDefault();this.go(0);}else if(event.key==='End'){event.preventDefault();this.go(this.scenes.length-1);}}
}
